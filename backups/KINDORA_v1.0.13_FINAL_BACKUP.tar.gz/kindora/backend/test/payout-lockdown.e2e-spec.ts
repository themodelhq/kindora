import request from 'supertest';
import type { NestExpressApplication } from '@nestjs/platform-express';
import { closeTestApp, createTestApp, getTestPrisma, maybeDescribe } from './setup';
import { base32Decode, hotp, TOTP_STEP_SECONDS } from '../src/mfa/totp.util';
import { PayoutInitiationService } from '../src/payouts/payout-initiation.service';
import { PayoutOutboxSweeper } from '../src/payouts/payout-outbox.sweeper';
import { MockPayoutAdapter } from '../src/payouts/adapters/mock-payout.adapter';
import { PayoutReconciliationService } from '../src/payouts/payout-reconciliation.service';
import { providerSubmissionReference } from '../src/payouts/payout-provider.adapter';

// MFA challenge exchanges legitimately wait out TOTP windows (30s each).
jest.setTimeout(300_000);

/**
 * KINDORA v1.0.9 §12 — duplicate payout prevention & final authorization
 * lockdown, integration-tested on REAL PostgreSQL + REAL Redis
 * (PROVIDER_MODE=mock):
 *
 *  1. The manual-settlement API rejects EVERY API provider name and arbitrary
 *     value at the DTO layer — the v1.0.7 settlement bypass stays closed.
 *  2. A settlement with an INVALID approval cycle or WITHOUT the authorized
 *     manual intent (no bound snapshot) is refused — legacy withdrawals are
 *     never grandfathered (§5.2).
 *  3. A legitimate manual settlement follows the TWO-STEP protocol: authorize
 *     the manual payout intent (binds the immutable snapshot) then settle with
 *     evidence — recorded with the DISTINCT MANUAL_EVIDENCE_RECORDED
 *     classification + the immutable audit event (§5.1).
 *  4. Outbox lease recovery: an IN_FLIGHT intent with an EXPIRED lease is
 *     reclaimed safely — the provider is consulted through the deterministic
 *     submission reference BEFORE any resubmission (§7).
 *  5. MANUAL SETTLEMENT AND PROVIDER SUBMISSION ARE MUTUALLY EXCLUSIVE: the
 *     in-lock recheck (unresolved attempts, pending outbox events) and the
 *     durable PayoutSettlementGuard make competing settlement paths
 *     impossible on REAL PostgreSQL (§3.1/§3.2).
 *  6. Ledger posting is exactly-once: reconciliation replays and repeated
 *     settlement attempts can never double-post (§10).
 */

const rand = Math.random().toString(36).slice(2, 10);
const ADMIN_EMAIL = 'admin@kindora.com';
const ADMIN_PASSWORD = process.env.SEED_ADMIN_PASSWORD ?? 'Kindora-Admin-2026!';

const organizerCreds = {
  email: `lock-organizer-${rand}@kindora.test`,
  password: 'LockOrganizer1!',
  firstName: 'Obi',
  lastName: 'Organizer',
};
const admin2Creds = {
  email: `lock-admin2-${rand}@kindora.test`,
  password: 'LockAdmin2Pass1!',
  firstName: 'Ngozi',
  lastName: 'Second',
};
const admin3Creds = {
  email: `lock-admin3-${rand}@kindora.test`,
  password: 'LockAdmin3Pass1!',
  firstName: 'Emeka',
  lastName: 'Executor',
};

const STORY =
  'This campaign exists to prove the v1.0.9 duplicate-payout prevention and final authorization lockdown end to end: ' +
  'the manual-settlement allowlist, the immutable approval snapshot protocol, the durable settlement guard and safe ' +
  'outbox lease recovery. All amounts are minor units tracked by the double-entry ledger.';

const DESTINATION = { accountName: 'Obi Organizer', accountNumber: '0234567890', bankName: 'Test Bank' };

maybeDescribe('Payout lockdown (e2e, v1.0.9)', () => {
  let app: NestExpressApplication;
  let organizerToken = '';
  let adminToken = '';
  let admin2Token = '';
  let admin3Token = '';
  let campaignId = '';
  let campaignSlug = '';

  function totpCode(secretBase32: string, stepOffset = 0): string {
    const buf = base32Decode(secretBase32.replace(/=+$/, ''));
    const counter = BigInt(Math.floor(Date.now() / 1000 / TOTP_STEP_SECONDS)) + BigInt(stepOffset);
    return hotp(buf, counter);
  }

  const enrolledSecrets = new Map<string, string>();

  async function exchangeChallenge(bearer: string, purpose: string, scope: string, secretBase32: string): Promise<string> {
    for (let win = 0; win < 3; win++) {
      for (const off of [0, 1]) {
        const attempt = await request(app.getHttpServer())
          .post('/api/v1/mfa/challenge')
          .set('Authorization', `Bearer ${bearer}`)
          .send({ purpose, scope, code: totpCode(secretBase32, off) });
        if (attempt.status === 200 || attempt.status === 201) {
          return attempt.body.challengeToken as string;
        }
        const msg = String(attempt.body?.message ?? '');
        if (!/already been used|Invalid or expired/.test(msg)) {
          throw new Error(`MFA challenge rejected unexpectedly (${attempt.status}): ${msg}`);
        }
      }
      await new Promise((r) => setTimeout(r, 30000 - (Date.now() % 30000) + 250));
    }
    throw new Error('No usable TOTP counter for MFA challenge after 3 windows');
  }

  async function freshMfa(bearer: string, purpose: string, scope: string): Promise<string> {
    const status = await request(app.getHttpServer()).get('/api/v1/mfa/status').set('Authorization', `Bearer ${bearer}`).expect(200);
    let secret = enrolledSecrets.get(bearer);
    if (!status.body.active) {
      const enroll = await request(app.getHttpServer()).post('/api/v1/mfa/enroll').set('Authorization', `Bearer ${bearer}`).expect([200, 201]);
      secret = enroll.body.secret as string;
      enrolledSecrets.set(bearer, secret);
      await request(app.getHttpServer()).post('/api/v1/mfa/confirm').set('Authorization', `Bearer ${bearer}`).send({ code: totpCode(secret) }).expect([200, 201]);
    } else if (!secret) {
      throw new Error('Account already has active MFA whose secret this run never received — use a fresh account');
    }
    return exchangeChallenge(bearer, purpose, scope, secret!);
  }

  async function makeEvidenceFile(uploaderId: string) {
    return getTestPrisma().storedFile.create({
      data: {
        key: `evidence/lockdown-suite-${rand}-${Math.random().toString(36).slice(2, 8)}.pdf`,
        kind: 'PAYOUT_EVIDENCE',
        visibility: 'PRIVATE',
        status: 'APPROVED',
        scanVerdict: 'CLEAN',
        fileName: 'bank-transfer-receipt.pdf',
        contentType: 'application/pdf',
        sizeBytes: 2048n,
        uploaderId,
      },
    });
  }

  /** Full approval chain: first approval (admin), second approval (admin2). */
  async function approveViaBothAdmins(withdrawalId: string): Promise<void> {
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/approve`)
      .set('Authorization', `Bearer ${adminToken}`)
      .set('x-mfa-challenge', await freshMfa(adminToken, 'PAYOUT_FIRST_APPROVAL', withdrawalId))
      .expect([200, 201]);
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/second-approval`)
      .set('Authorization', `Bearer ${admin2Token}`)
      .set('x-mfa-challenge', await freshMfa(admin2Token, 'PAYOUT_SECOND_APPROVAL', withdrawalId))
      .send({ note: 'lockdown suite second approval' })
      .expect([200, 201]);
  }

  /** Creates a funded, fully-approved withdrawal and returns its id. */
  async function createApprovedWithdrawal(amountMinor: number): Promise<string> {
    const created = await request(app.getHttpServer())
      .post('/api/v1/withdrawals')
      .set('Authorization', `Bearer ${organizerToken}`)
      .send({ campaignId, amountMinor, method: 'BANK', destination: DESTINATION })
      .expect(201);
    const id = created.body.id as string;
    await approveViaBothAdmins(id);
    return id;
  }

  /**
   * v1.0.10 §6.2 — bounded CONDITION wait (awaitility-style). The deferred
   * promise barriers establish the exact ordering; this helper only handles
   * the one remaining nondeterminism — WHICH worker (an in-test call or the
   * 1s outbox sweeper) claims the durable lease — by waiting for the DURABLE
   * database outcome instead of relying on the caller's identity.
   */
  async function waitFor(condition: () => Promise<boolean>, description: string, timeoutMs = 20_000): Promise<void> {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (await condition()) return;
      await new Promise((r) => setTimeout(r, 100));
    }
    throw new Error(`condition not reached within ${timeoutMs}ms: ${description}`);
  }

  /** The deterministic provider submission reference of a fresh withdrawal's first attempt. */
  function expectedReferenceFor(withdrawalId: string): string {
    return providerSubmissionReference(`payout:${withdrawalId}:1`);
  }

  beforeAll(async () => {
    app = await createTestApp();

    // The seeded admin's MFA may be ACTIVE from a previous suite run against
    // this persistent database; its enrollment secret is intentionally not
    // retrievable, so reset it to get a clean enrollment for THIS run.
    await getTestPrisma().mfaCredential.deleteMany({ where: { user: { email: ADMIN_EMAIL } } });

    await request(app.getHttpServer()).post('/api/v1/auth/register').send(organizerCreds).expect(201);
    await request(app.getHttpServer()).post('/api/v1/auth/register').send(admin2Creds).expect(201);
    await request(app.getHttpServer()).post('/api/v1/auth/register').send(admin3Creds).expect(201);
    await getTestPrisma().user.update({ where: { email: admin2Creds.email }, data: { role: 'ADMIN' } });
    await getTestPrisma().user.update({ where: { email: admin3Creds.email }, data: { role: 'ADMIN' } });
    await request(app.getHttpServer()).post('/api/v1/auth/dev/complete-verification').send({ email: organizerCreds.email }).expect(200);

    const organizerLogin = await request(app.getHttpServer()).post('/api/v1/auth/login').send({ email: organizerCreds.email, password: organizerCreds.password }).expect([200, 201]);
    organizerToken = organizerLogin.body.accessToken;
    const admin2Login = await request(app.getHttpServer()).post('/api/v1/auth/login').send({ email: admin2Creds.email, password: admin2Creds.password }).expect([200, 201]);
    admin2Token = admin2Login.body.accessToken;
    const admin3Login = await request(app.getHttpServer()).post('/api/v1/auth/login').send({ email: admin3Creds.email, password: admin3Creds.password }).expect([200, 201]);
    admin3Token = admin3Login.body.accessToken;
    const adminLogin = await request(app.getHttpServer()).post('/api/v1/auth/login').send({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD }).expect([200, 201]);
    adminToken = adminLogin.body.accessToken;

    const created = await request(app.getHttpServer())
      .post('/api/v1/campaigns')
      .set('Authorization', `Bearer ${organizerToken}`)
      .send({
        title: `Payout Lockdown Campaign ${rand}`,
        excerpt: 'v1.0.8 lockdown suite.',
        story: STORY,
        categorySlug: 'education',
        country: 'Nigeria',
        targetAmountMajor: 1000000,
        currency: 'NGN',
      })
      .expect(201);
    campaignId = created.body.campaign.id as string;
    campaignSlug = created.body.campaign.slug as string;
    await request(app.getHttpServer()).post(`/api/v1/campaigns/${campaignId}/submit`).set('Authorization', `Bearer ${organizerToken}`).expect([200, 201]);
    await request(app.getHttpServer()).post(`/api/v1/admin/campaigns/${campaignId}/approve`).set('Authorization', `Bearer ${adminToken}`).send({ note: 'lockdown suite' }).expect([200, 201]);

    // Fund the campaign with a REAL mock-provider donation.
    const donation = await request(app.getHttpServer())
      .post('/api/v1/donations')
      .set('Authorization', `Bearer ${organizerToken}`)
      .send({ campaignSlug, amountMinor: 8000000, provider: 'MOCK' })
      .expect(201);
    const publicRef = donation.body.donation.publicRef as string;
    await request(app.getHttpServer()).get(`/api/v1/donations/status/PAYSTACK/${publicRef}`).expect(200);
  });

  afterAll(async () => {
    await closeTestApp();
  });

  it('§12.1: the manual-settlement API rejects EVERY API provider name and arbitrary value at the DTO layer', async () => {
    const withdrawalId = await createApprovedWithdrawal(300000);
    const evidence = await makeEvidenceFile((await getTestPrisma().user.findUnique({ where: { email: admin3Creds.email } }))!.id);
    for (const provider of [
      'PAYSTACK',
      'PAYSTACK_TRANSFER',
      'FLUTTERWAVE',
      'FLUTTERWAVE_TRANSFER',
      'STRIPE',
      'PAYPAL',
      'MOCK',
      'MANUAL_BANK', // v1.0.4-v1.0.7 legacy name — no longer a settlement input
      'SOMETHING_ELSE', // arbitrary administrator string
      'paystack_transfer',
    ]) {
      // Each attempt needs a FRESH single-use MFA challenge: the guard runs
      // before the DTO, and the challenge is replay-locked by design.
      const challenge = await freshMfa(admin3Token, 'PAYOUT_SETTLEMENT', withdrawalId);
      const res = await request(app.getHttpServer())
        .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
        .set('Authorization', `Bearer ${admin3Token}`)
        .set('x-mfa-challenge', challenge)
        .send({ payoutProvider: provider, providerTransferRef: `trf-${rand}`, evidenceFileId: evidence.id });
      expect(res.status).toBe(400);
      expect(JSON.stringify(res.body)).toContain('approved manual channels');
    }
    // The withdrawal was NOT settled by any of the bypass attempts, and the
    // MFA-challenge reuse means later attempts are still rejected at the DTO
    // (single-use challenges leak nothing to the attacker).
    const w = await getTestPrisma().withdrawal.findUnique({ where: { id: withdrawalId } });
    expect(w!.status).not.toBe('PAID');
  });

  it('§4.5: settlement with an INVALIDATED approval cycle is refused even for an allowlisted channel', async () => {
    const withdrawalId = await createApprovedWithdrawal(400000);
    // Destination change invalidates the current approval cycle (§5.4).
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/destination`)
      .set('Authorization', `Bearer ${organizerToken}`)
      .send({ destination: { ...DESTINATION, accountNumber: '0987654321' } })
      .expect([200, 201]);
    const approvals = await getTestPrisma().withdrawalApproval.findMany({ where: { withdrawalId } });
    expect(approvals.every((a) => a.status !== 'ACTIVE' || a.cycle !== 1)).toBe(true);

    const evidence = await makeEvidenceFile((await getTestPrisma().user.findUnique({ where: { email: admin3Creds.email } }))!.id);
    const res = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_SETTLEMENT', withdrawalId))
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', providerTransferRef: `trf-invalid-${rand}`, evidenceFileId: evidence.id });
    expect([403, 409]).toContain(res.status);
    // Either the missing authorized manual intent (v1.0.9 §5.2 — no bound
    // snapshot, no grandfathering), the settlement-time dual-approval
    // pre-check or the in-transaction approval-cycle validator refuses the
    // settlement — all fail closed.
    expect(JSON.stringify(res.body)).toMatch(/manual payout intent|approval cycle|second administrator|separation|executor/);
    const w = await getTestPrisma().withdrawal.findUnique({ where: { id: withdrawalId } });
    expect(w!.status).not.toBe('PAID');
  });

  it('§5.1/§3.4: a legitimate manual settlement follows the TWO-STEP protocol (intent authorization binds the snapshot) and records MANUAL_EVIDENCE_RECORDED', async () => {
    const withdrawalId = await createApprovedWithdrawal(500000);
    const executorId = (await getTestPrisma().user.findUnique({ where: { email: admin3Creds.email } }))!.id;

    // STEP 1 — authorize the manual payout intent (binds the immutable
    // manual approval snapshot on BOTH approvals, §5.1).
    const intentRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId))
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', note: 'offline settlement authorized' })
      .expect([200, 201]);
    const intentAttemptId = intentRes.body.id as string;
    const intentAttempt = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: intentAttemptId } });
    expect(intentAttempt.status).toBe('INITIATED');
    expect(intentAttempt.provider).toBe('MANUAL_BANK_TRANSFER');
    // The snapshot is bound on both approvals.
    const approvals = await getTestPrisma().withdrawalApproval.findMany({ where: { withdrawalId, cycle: (await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } })).approvalCycle, status: 'ACTIVE' } });
    expect(approvals).toHaveLength(2);
    expect(approvals[0].snapshotHash).toBeTruthy();
    expect(approvals[1].snapshotHash).toBe(approvals[0].snapshotHash);

    // STEP 2 — settle with registered evidence.
    const evidence = await makeEvidenceFile(executorId);
    const res = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_SETTLEMENT', withdrawalId))
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', providerTransferRef: `trf-ok-${rand}`, evidenceFileId: evidence.id, note: 'paid at the bank branch' });
    expect([200, 201]).toContain(res.status);

    const w = await getTestPrisma().withdrawal.findUnique({ where: { id: withdrawalId } });
    expect(w!.status).toBe('PAID');
    expect(w!.payoutProvider).toBe('MANUAL_BANK_TRANSFER');

    const reconciliation = await getTestPrisma().payoutReconciliation.findFirstOrThrow({
      where: { withdrawalId },
      orderBy: { createdAt: 'desc' },
    });
    // v1.0.8 §3.4 — a manual settlement NEVER manufactures provider verification.
    expect(reconciliation.result).toBe('MANUAL_EVIDENCE_RECORDED');

    const attempt = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: intentAttemptId } });
    expect(attempt.manualChannel).toBe('MANUAL_BANK_TRANSFER');
    expect(attempt.status).toBe('SUCCESSFUL');

    // §3.2 — the coordination guard is TERMINAL after settlement.
    const guard = await getTestPrisma().payoutSettlementGuard.findUniqueOrThrow({ where: { withdrawalId } });
    expect(guard.mode).toBe('SETTLED');

    const audit = await getTestPrisma().auditLog.findFirstOrThrow({ where: { entityId: withdrawalId, action: 'WITHDRAWAL_PAID_MANUAL_SETTLEMENT' }, orderBy: { createdAt: 'desc' } });
    const meta = audit.metadata as Record<string, unknown>;
    expect(meta.settlementChannel).toBe('MANUAL_BANK_TRANSFER');
    expect(meta.executorId).toBe(executorId);
    expect(meta.approvalCycleId).toContain('#cycle');
    // §5.1 — the authorization event carries the bound snapshot hash.
    const intentAudit = await getTestPrisma().auditLog.findFirstOrThrow({ where: { entityId: withdrawalId, action: 'PAYOUT_MANUAL_INTENT_AUTHORIZED' }, orderBy: { createdAt: 'desc' } });
    expect((intentAudit.metadata as Record<string, unknown>).approvalSnapshotHash).toBe(approvals[0].snapshotHash);
  });

  it('§3.1/§3.2: manual settlement is BLOCKED while a provider submission is pending or in flight (in-lock recheck + durable guard)', async () => {
    // v1.0.12 §10 — deterministic scheduling barrier. The ONLY remaining
    // nondeterminism in this scenario was a background outbox sweep landing
    // between the intent commit and the in-test submitOutbox call: the sweep
    // would claim the intent first and the in-test call would observe
    // ALREADY_SUBMITTED instead of the guard-driven LOOKUP_PENDING deferral.
    // Pausing the sweeper's timer (and waiting out any in-flight sweep) makes
    // the in-test call the only possible submission worker for the critical
    // section; the timer is restored in finally so every other scenario keeps
    // the real two-worker behavior. No assertion, ordering or timeout changed.
    const sweeper = app.get(PayoutOutboxSweeper);
    await sweeper.pauseScheduling();
    try {
      const withdrawalId = await createApprovedWithdrawal(550000);
      const executorId = (await getTestPrisma().user.findUnique({ where: { email: admin3Creds.email } }))!.id;

      // Commit a REAL provider payout intent: withdrawal PROCESSING, attempt
      // INITIATED, outbox PENDING (the queue is not consumed inside the test).
      const executeRes = await request(app.getHttpServer())
        .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
        .set('Authorization', `Bearer ${admin3Token}`)
        .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId))
        .send({ payoutProvider: 'MOCK' })
        .expect([200, 201]);
      expect(executeRes.body.id).toBeTruthy();

      // The coordination guard was created with the intent and is IDLE, but the
      // in-lock recheck sees the UNRESOLVED attempt + PENDING outbox event.
      const evidence = await makeEvidenceFile(executorId);
      const res = await request(app.getHttpServer())
        .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
        .set('Authorization', `Bearer ${admin3Token}`)
        .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_SETTLEMENT', withdrawalId))
        .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', providerTransferRef: `trf-race-${rand}`, evidenceFileId: evidence.id });
      expect(res.status).toBe(409);
      expect(JSON.stringify(res.body)).toMatch(/unresolved|pending or in flight/);
      const w = await getTestPrisma().withdrawal.findUnique({ where: { id: withdrawalId } });
      expect(w!.status).not.toBe('PAID');

      // The mirror direction: the submission path DEFERS while the guard is
      // claimed by a manual settlement (simulate the claim with a valid lease).
      await getTestPrisma().$executeRawUnsafe(
        `UPDATE "PayoutSettlementGuard" SET "mode" = 'MANUAL_SETTLEMENT_ACTIVE', "claimedBy" = 'manual-tx', "claimedAt" = now(), "updatedAt" = now() WHERE "withdrawalId" = $1`,
        withdrawalId,
      );
      const submission = await app.get(PayoutInitiationService).submitOutbox((executeRes.body.id as string));
      expect(submission.action).toBe('LOOKUP_PENDING');
      expect(submission.detail).toContain('guard');
      // No provider transfer was created for the attempt.
      const attempt = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: executeRes.body.id as string } });
      expect(attempt.providerTransferRef).toBeNull();
    } finally {
      sweeper.resumeScheduling();
    }
  });

  /**
   * v1.0.10 §6.1 — the v1.0.9 "§3.2/§12.5 concurrent manual settlement and
   * provider submission" test was RETIRED: it called settleManual() directly
   * WITHOUT an authorized manual settlement intent and had no controlled
   * provider delay, so it only proved the rejection of an INVALID manual
   * attempt — not the two-valid-competing-paths guarantee. It is replaced by
   * the deterministic scenario suite below (§6.3-§6.9), where:
   *   - every manual settlement goes through the ACTUAL authorized workflow
   *     (two-step intent authorization + fresh MFA + evidence);
   *   - the mock provider HOLDS requests in flight behind deferred-promise
   *     barriers (no arbitrary sleeps);
   *   - every scenario asserts final withdrawal status, attempt status,
   *     lease/guard state, provider request count, provider reference count,
   *     settlement records, ledger entries (exactly one), the amount in
   *     minor units and the audit trail.
   */

  it('v1.0.10 §6.3 (A): an authorized manual-settlement intent and an API provider initiation race on REAL PostgreSQL — exactly ONE payment path may win', async () => {
    const withdrawalId = await createApprovedWithdrawal(650000);

    // Both MFA challenges are exchanged BEFORE the race: the race itself must
    // be between the two AUTHORIZED operations, not their MFA setups.
    const manualChallenge = await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId);
    const providerChallenge = await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId);

    // Path A — a VALID manual settlement authorization intent (the actual
    // two-step workflow, step one). Path B — a VALID API provider payout
    // initiation. Fired CONCURRENTLY on the real database.
    const [manualRes, providerRes] = await Promise.all([
      request(app.getHttpServer())
        .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
        .set('Authorization', `Bearer ${admin3Token}`)
        .set('x-mfa-challenge', manualChallenge)
        .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', note: 'scenario A manual settlement intent' }),
      request(app.getHttpServer())
        .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
        .set('Authorization', `Bearer ${admin3Token}`)
        .set('x-mfa-challenge', providerChallenge)
        .send({ payoutProvider: 'MOCK' }),
    ]);

    const manualWon = [200, 201].includes(manualRes.status);
    const providerWon = [200, 201].includes(providerRes.status);
    // The authoritative coordination permits exactly ONE path to acquire the
    // settlement/submission right; the loser is rejected.
    expect(manualWon !== providerWon).toBe(true);

    const w = await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
    const attempts = await getTestPrisma().payoutAttempt.findMany({ where: { withdrawalId } });
    const outboxes = await getTestPrisma().payoutOutbox.findMany({ where: { withdrawalId } });
    const guard = await getTestPrisma().payoutSettlementGuard.findUniqueOrThrow({ where: { withdrawalId } });
    const ledgerTxns = await getTestPrisma().ledgerTransaction.count({ where: { reference: `withdrawal:${withdrawalId}` } });
    expect(attempts).toHaveLength(1); // exactly one durable intent exists

    if (manualWon) {
      // The manual intent won: the provider initiation is rejected and NO
      // provider submission artifact may exist.
      expect(providerRes.status).toBe(409);
      expect(w.status).toBe('APPROVED');
      expect(attempts[0].provider).toBe('MANUAL_BANK_TRANSFER');
      expect(attempts[0].status).toBe('INITIATED');
      expect(outboxes).toHaveLength(0);
      expect(guard.mode).toBe('IDLE');
    } else {
      // The provider initiation won: the manual intent is rejected.
      expect(manualRes.status).toBe(409);
      expect(w.status).toBe('PROCESSING');
      expect(attempts[0].provider).toBe('MOCK');
      expect(attempts[0].initiatedById).toBe((await getTestPrisma().user.findUniqueOrThrow({ where: { email: admin3Creds.email } })).id);
      expect(outboxes).toHaveLength(1);
    }
    // Either way: no settlement has happened, no ledger posting exists, and
    // the coordination guard is NOT terminal.
    expect(guard.mode).not.toBe('SETTLED');
    expect(ledgerTxns).toBe(0);
  });

  it('v1.0.10 §6.4 (B): provider submission held in flight — manual settlement cannot proceed; the provider payout is the ONLY settlement', async () => {
    const withdrawalId = await createApprovedWithdrawal(660000);
    const executorId = (await getTestPrisma().user.findUniqueOrThrow({ where: { email: admin3Creds.email } })).id;

    // 1-2. Create the approved withdrawal and initiate the provider payout.
    const executeRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId))
      .send({ payoutProvider: 'MOCK' })
      .expect([200, 201]);
    const attemptId = executeRes.body.id as string;

    // 3-4. Start the outbox worker and PAUSE the provider request for THIS
    // reference at the boundary (deferred-promise barrier — no sleeps; the
    // hold is scoped to this logical payout so out-of-band submissions flow).
    const mock = app.get(MockPayoutAdapter);
    const reference = expectedReferenceFor(withdrawalId);
    mock.resetCounters();
    const heldRef = new Promise<string>((resolve) => mock.onInitiationHeld(resolve));
    mock.setInitiationHold(true, { registerOnReceipt: true, reference });
    void app.get(PayoutInitiationService).submitOutbox(attemptId).catch(() => undefined);
    expect(await heldRef).toBe(reference);

    // 5. The durable submission state is ACTIVE while the request is in flight.
    const outboxDuringFlight = await getTestPrisma().payoutOutbox.findUniqueOrThrow({ where: { attemptId } });
    expect(outboxDuringFlight.status).toBe('IN_FLIGHT');
    expect(outboxDuringFlight.claimedBy).toBeTruthy();
    expect(outboxDuringFlight.leaseExpiresAt!.getTime()).toBeGreaterThan(Date.now());
    const attemptDuringFlight = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } });
    expect(attemptDuringFlight.providerTransferRef).toBeNull(); // nothing persisted yet
    const guardDuringFlight = await getTestPrisma().payoutSettlementGuard.findUniqueOrThrow({ where: { withdrawalId } });
    expect(guardDuringFlight.mode).toBe('PROVIDER_SUBMISSION_ACTIVE');
    const wDuringFlight = await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
    expect(wDuringFlight.status).toBe('PROCESSING'); // funds reserved

    // 6-7. Manual settlement through the ACTUAL authorized workflow (intent
    // protocol + fresh MFA + evidence) cannot proceed.
    const evidence = await makeEvidenceFile(executorId);
    const settleRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_SETTLEMENT', withdrawalId))
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', providerTransferRef: `trf-flight-${rand}`, evidenceFileId: evidence.id });
    expect(settleRes.status).toBe(409);
    expect(JSON.stringify(settleRes.body)).toMatch(/unresolved|pending or in flight|settlement path/i);

    // 8. Allow the provider to return a successful transfer. Whichever worker
    // owned the lease (an in-test call or the sweeper) persists the
    // acceptance — the DURABLE outcome is what the scenario asserts.
    await mock.releaseHeldInitiation('accept');
    await waitFor(async () => (await getTestPrisma().payoutAttempt.findUnique({ where: { id: attemptId } }))?.providerTransferRef === reference, 'the provider acceptance is persisted with the exact reference');
    mock.setInitiationHold(false);
    const attemptAfterAccept = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } });
    expect(attemptAfterAccept.providerTransferRef).toBe(reference);

    // 9-10. Reconcile the original transfer; the provider payout is the ONLY settlement.
    const reconciliation = app.get(PayoutReconciliationService);
    const beneficiaryRef = (await getTestPrisma().payoutBeneficiary.findFirstOrThrow({ where: { withdrawalId, provider: 'MOCK' } })).externalRef;
    await reconciliation.apply({
      attemptId,
      source: 'RECONCILIATION_SWEEP' as never,
      verification: { classification: 'SUCCESSFUL' as never, providerStatus: 'success', providerReference: reference, amountMinor: attemptAfterAccept.amount, currency: attemptAfterAccept.currency, beneficiaryRef, evidence: { status: 'success' } },
    });

    const w = await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
    expect(w.status).toBe('PAID');
    expect(w.amount).toBe(660000n); // financial amount in minor units
    const attempt = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } });
    expect(attempt.status).toBe('SUCCESSFUL');
    const guard = await getTestPrisma().payoutSettlementGuard.findUniqueOrThrow({ where: { withdrawalId } });
    expect(guard.mode).toBe('SETTLED');
    const ledgerTxns = await getTestPrisma().ledgerTransaction.count({ where: { reference: `withdrawal:${withdrawalId}` } });
    expect(ledgerTxns).toBe(1);
    // Provider request count / provider reference count: exactly one transfer.
    expect(mock.initiationCount(reference)).toBe(1);
    expect(mock.hasTransfer(reference)).toBe(true);
    // Audit trail: the acceptance and the provider-verified settlement.
    const acceptedAudit = await getTestPrisma().auditLog.findFirstOrThrow({ where: { entityId: withdrawalId, action: 'PAYOUT_TRANSFER_ACCEPTED' }, orderBy: { createdAt: 'desc' } });
    expect(acceptedAudit).toBeTruthy();
    const settledAudit = await getTestPrisma().auditLog.findFirstOrThrow({ where: { entityId: withdrawalId, action: 'PAYOUT_SETTLED_PROVIDER_VERIFIED' }, orderBy: { createdAt: 'desc' } });
    expect((settledAudit.metadata as Record<string, unknown>).providerReference).toBe(reference);
  });

  it('v1.0.10 §6.5 (C): the authorized manual settlement path wins FIRST — provider initiation cannot obtain submission authorization; exactly one settlement', async () => {
    const withdrawalId = await createApprovedWithdrawal(670000);
    const executorId = (await getTestPrisma().user.findUniqueOrThrow({ where: { email: admin3Creds.email } })).id;

    // 1-2. Authorize the manual settlement path with the correct approval
    // snapshot (two-step protocol, step one) — the guard is acquired and the
    // intent commits durably.
    const intentRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId))
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', note: 'scenario C manual intent wins' })
      .expect([200, 201]);
    expect(intentRes.body.id).toBeTruthy();

    // 3-5. Provider initiation attempts to run against the SAME withdrawal
    // (fresh MFA, real API path) — it CANNOT obtain submission authorization.
    const providerRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId))
      .send({ payoutProvider: 'MOCK' });
    expect(providerRes.status).toBe(409);
    // Fail-closed rejection — EITHER the pre-transaction unresolved-attempt
    // check or the approval-snapshot binding defense (the manual intent bound
    // the MANUAL snapshot; the provider initiation computes a different hash).
    // Both prove the provider initiation cannot obtain submission
    // authorization while an authorized manual intent is outstanding.
    expect(JSON.stringify(providerRes.body)).toMatch(/unresolved|snapshot/i);
    const attempts = await getTestPrisma().payoutAttempt.findMany({ where: { withdrawalId } });
    expect(attempts).toHaveLength(1); // only the manual intent exists
    expect(attempts[0].provider).toBe('MANUAL_BANK_TRANSFER');
    expect(await getTestPrisma().payoutOutbox.count({ where: { withdrawalId } })).toBe(0);

    // 6. Complete the manual settlement through the authorized workflow.
    const evidence = await makeEvidenceFile(executorId);
    const settleRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_SETTLEMENT', withdrawalId))
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', providerTransferRef: `trf-manual-win-${rand}`, evidenceFileId: evidence.id })
      .expect([200, 201]);
    expect(settleRes.status).toBeLessThan(300);

    // 7. The outbox worker cannot submit a provider transfer afterward: the
    // manual intent never produced an outbox row and the guard is TERMINAL.
    expect(await getTestPrisma().payoutOutbox.count({ where: { withdrawalId } })).toBe(0);
    const guard = await getTestPrisma().payoutSettlementGuard.findUniqueOrThrow({ where: { withdrawalId } });
    expect(guard.mode).toBe('SETTLED');

    // 8. Exactly ONE settlement and ONE ledger entry.
    const w = await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
    expect(w.status).toBe('PAID');
    expect(w.payoutProvider).toBe('MANUAL_BANK_TRANSFER');
    expect(w.amount).toBe(670000n);
    expect(await getTestPrisma().ledgerTransaction.count({ where: { reference: `withdrawal:${withdrawalId}` } })).toBe(1);
    const settlementAudits = await getTestPrisma().auditLog.count({ where: { entityId: withdrawalId, action: 'WITHDRAWAL_PAID_MANUAL_SETTLEMENT' } });
    expect(settlementAudits).toBe(1);
    const paidAudit = await getTestPrisma().auditLog.findFirstOrThrow({ where: { entityId: withdrawalId, action: 'WITHDRAWAL_PAID_MANUAL_SETTLEMENT' } });
    expect((paidAudit.metadata as Record<string, unknown>).executorId).toBe(executorId);
  });

  it('v1.0.10 §6.6 (D): the provider accepted the transfer and the worker crashed before persisting — recovery adopts the ORIGINAL transfer, never submits twice', async () => {
    const withdrawalId = await createApprovedWithdrawal(680000);
    const executeRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId))
      .send({ payoutProvider: 'MOCK' })
      .expect([200, 201]);
    const attemptId = executeRes.body.id as string;

    const mock = app.get(MockPayoutAdapter);
    const reference = expectedReferenceFor(withdrawalId);
    mock.resetCounters();
    const heldRef = new Promise<string>((resolve) => mock.onInitiationHeld(resolve));
    mock.setInitiationHold(true, { registerOnReceipt: true, reference });
    // Worker #1 reaches the provider boundary — the provider ACCEPTS and
    // registers the transfer — and then "crashes": the held response is
    // never released, so the worker never persists anything.
    const crashedWorker = app.get(PayoutInitiationService).submitOutbox(attemptId).catch(() => undefined);
    expect(await heldRef).toBe(reference);
    expect(mock.initiationCount(reference)).toBe(1);
    const outbox = await getTestPrisma().payoutOutbox.findUniqueOrThrow({ where: { attemptId } });
    expect(outbox.status).toBe('IN_FLIGHT');
    // Simulate the worker termination: BOTH durable leases expire with
    // nothing persisted — the outbox submission lease AND the coordination
    // guard's submission lease (the same lease window in production).
    await getTestPrisma().payoutOutbox.update({
      where: { id: outbox.id },
      data: { claimedBy: 'crashed-worker', claimedAt: new Date(Date.now() - 20 * 60_000), leaseExpiresAt: new Date(Date.now() - 10 * 60_000) },
    });
    await getTestPrisma().$executeRawUnsafe(`UPDATE "PayoutSettlementGuard" SET "claimedUntil" = now() - interval '10 minutes', "updatedAt" = now() WHERE "withdrawalId" = $1`, withdrawalId);
    const crashedAttempt = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } });
    expect(crashedAttempt.providerTransferRef).toBeNull();

    // 4. The worker restarts: recovery looks the transfer up FIRST. Whichever
    // worker reclaims the expired lease (the in-test call or the sweeper),
    // the DURABLE outcome is the adoption of the EXACT original reference.
    mock.setInitiationHold(false);
    await app.get(PayoutInitiationService).submitOutbox(attemptId).catch(() => undefined);
    await waitFor(async () => (await getTestPrisma().payoutAttempt.findUnique({ where: { id: attemptId } }))?.providerTransferRef === reference, 'the recovery adopts the original transfer');

    // 5-7. The original transfer is reconciled; no second transfer exists.
    // (The adopted transfer carries the mock's 'pending' provider status, so
    // the attempt sits in PENDING — the reconcilable, unresolved-until-verified
    // state — after adoption.)
    const attempt = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } });
    expect(attempt.providerTransferRef).toBe(reference);
    expect(['PENDING', 'PROVIDER_ACCEPTED']).toContain(attempt.status);
    expect(mock.initiationCount(reference)).toBe(1); // exactly ONE provider request total
    expect(mock.hasTransfer(reference)).toBe(true); // exactly ONE provider transfer for this reference

    const reconciliation = app.get(PayoutReconciliationService);
    const beneficiaryRef = (await getTestPrisma().payoutBeneficiary.findFirstOrThrow({ where: { withdrawalId, provider: 'MOCK' } })).externalRef;
    await reconciliation.apply({
      attemptId,
      source: 'RECONCILIATION_SWEEP' as never,
      verification: { classification: 'SUCCESSFUL' as never, providerStatus: 'success', providerReference: reference, amountMinor: attempt.amount, currency: attempt.currency, beneficiaryRef, evidence: { status: 'success' } },
    });
    const w = await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
    expect(w.status).toBe('PAID');
    expect(w.amount).toBe(680000n);
    expect(await getTestPrisma().ledgerTransaction.count({ where: { reference: `withdrawal:${withdrawalId}` } })).toBe(1);
    expect(await getTestPrisma().payoutSettlementGuard.findUniqueOrThrow({ where: { withdrawalId } }).then((g) => g.mode)).toBe('SETTLED');
    void crashedWorker; // the crashed worker never settles its held response
  });

  it('v1.0.10 §6.7 (E): ambiguous provider lookups preserve the reservation and keep manual settlement blocked — the original transfer is reconciled once lookups recover', async () => {
    const withdrawalId = await createApprovedWithdrawal(700000);
    const executorId = (await getTestPrisma().user.findUniqueOrThrow({ where: { email: admin3Creds.email } })).id;
    // v1.0.12 §10 — deterministic scheduling barrier (root-caused after the
    // chunked A/B reproduction on pristine v1.0.10 AND pristine v1.0.11: both
    // fail identically, so the interference is pre-existing). The background
    // 30s outbox sweeper can claim the due intent INSIDE the forced-outcome
    // window, take the currently-armed AMBIGUOUS override, and re-queue the
    // intent with an exponential backoff — after which the final in-test
    // recovery call is locked out by that backoff ("not yet due") and nothing
    // adopts the original transfer within the assertion window. Pausing the
    // sweeper makes the test's own submitOutbox calls the ONLY submission
    // workers for this scenario (the same barrier discipline as §3.1/§3.2);
    // the timer is restored in finally. No assertion, ordering or timeout
    // changed; production scheduling behavior is untouched.
    const sweeper = app.get(PayoutOutboxSweeper);
    await sweeper.pauseScheduling();
    try {
      const executeRes = await request(app.getHttpServer())
        .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
        .set('Authorization', `Bearer ${admin3Token}`)
        .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId))
        .send({ payoutProvider: 'MOCK' })
        .expect([200, 201]);
      const attemptId = executeRes.body.id as string;

    // 1-3. Provider accepts the transfer; the worker crashes before persistence.
    const mock = app.get(MockPayoutAdapter);
    const reference = expectedReferenceFor(withdrawalId);
    mock.resetCounters();
    const heldRef = new Promise<string>((resolve) => mock.onInitiationHeld(resolve));
    mock.setInitiationHold(true, { registerOnReceipt: true, reference });
    void app.get(PayoutInitiationService).submitOutbox(attemptId).catch(() => undefined);
    expect(await heldRef).toBe(reference);
    const outbox = await getTestPrisma().payoutOutbox.findUniqueOrThrow({ where: { attemptId } });
    await getTestPrisma().payoutOutbox.update({
      where: { id: outbox.id },
      data: { claimedBy: 'crashed-worker', claimedAt: new Date(Date.now() - 20 * 60_000), leaseExpiresAt: new Date(Date.now() - 10 * 60_000) },
    });
    await getTestPrisma().$executeRawUnsafe(`UPDATE "PayoutSettlementGuard" SET "claimedUntil" = now() - interval '10 minutes', "updatedAt" = now() WHERE "withdrawalId" = $1`, withdrawalId);

    // 4. The restarted worker's provider lookups return the ambiguous/error
    // classes: 401/403 (ERROR), 429/500/timeout/malformed/ambiguous identity
    // (AMBIGUOUS). The mock maps these HTTP classes to the same outcome
    // values the real adapters produce (unit-proven in the §9 matrix).
    for (const forced of [
      { outcome: 'ERROR' as const, reason: 'lookup rejected with HTTP 401 (authentication/authorization)' },
      { outcome: 'ERROR' as const, reason: 'lookup rejected with HTTP 403' },
      { outcome: 'AMBIGUOUS' as const, reason: 'lookup rate-limited (HTTP 429)' },
      { outcome: 'AMBIGUOUS' as const, reason: 'provider error (HTTP 500)' },
      { outcome: 'AMBIGUOUS' as const, reason: 'lookup transport failure: The operation was aborted due to timeout' },
      { outcome: 'AMBIGUOUS' as const, reason: 'lookup response is not the documented success envelope (malformed)' },
      { outcome: 'AMBIGUOUS' as const, reason: 'detailed transfer record reference differs from the requested reference — identity mismatch' },
    ]) {
      mock.forceLookupOutcome(reference, forced.outcome, forced.reason);
      await app.get(PayoutInitiationService).submitOutbox(attemptId).catch(() => undefined);
      // The DURABLE record of the lookup outcome (whoever ran the recovery).
      await waitFor(async () => (await getTestPrisma().payoutOutbox.findUnique({ where: { attemptId } }))?.lastLookupOutcome === forced.outcome, `lookup outcome ${forced.outcome} is recorded durably`);
      // 5. The payout remains reserved (funds NOT released).
      const w = await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
      expect(w.status).toBe('PROCESSING');
      const attempt = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } });
      expect(['INITIATED', 'SUBMISSION_PENDING']).toContain(attempt.status);
      // 7. No second transfer is submitted.
      expect(mock.initiationCount(reference)).toBe(1);
      // Re-arm the durable intent for the next recovery attempt (scheduling
      // adjustment only — the backoff window is a test-harness concern).
      await getTestPrisma().payoutOutbox.update({ where: { id: outbox.id }, data: { nextRunAt: new Date(Date.now() - 1_000) } });
    }

    // 6. Manual settlement remains blocked through the AUTHORIZED workflow.
    const evidence = await makeEvidenceFile(executorId);
    const settleRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_SETTLEMENT', withdrawalId))
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', providerTransferRef: `trf-amb-${rand}`, evidenceFileId: evidence.id });
    expect(settleRes.status).toBe(409);

    // 8-9. Restore provider lookup availability: the original exact-reference
    // transfer is returned.
    mock.clearLookupOverrides();
    mock.setInitiationHold(false);
    await app.get(PayoutInitiationService).submitOutbox(attemptId).catch(() => undefined);
    await waitFor(async () => (await getTestPrisma().payoutAttempt.findUnique({ where: { id: attemptId } }))?.providerTransferRef === reference, 'the recovered lookup adopts the original exact-reference transfer');

    // 10-11. Reconcile the EXISTING transfer; exactly one final settlement.
    const attempt = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } });
    const reconciliation = app.get(PayoutReconciliationService);
    const beneficiaryRef = (await getTestPrisma().payoutBeneficiary.findFirstOrThrow({ where: { withdrawalId, provider: 'MOCK' } })).externalRef;
    await reconciliation.apply({
      attemptId,
      source: 'RECONCILIATION_SWEEP' as never,
      verification: { classification: 'SUCCESSFUL' as never, providerStatus: 'success', providerReference: reference, amountMinor: attempt.amount, currency: attempt.currency, beneficiaryRef, evidence: { status: 'success' } },
    });
    const w = await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
    expect(w.status).toBe('PAID');
    expect(w.amount).toBe(700000n);
    expect(await getTestPrisma().ledgerTransaction.count({ where: { reference: `withdrawal:${withdrawalId}` } })).toBe(1);
    expect(mock.initiationCount(reference)).toBe(1);
    expect(mock.hasTransfer(reference)).toBe(true);
    } finally {
      sweeper.resumeScheduling();
    }
  });

  it('v1.0.10 §6.8 (F): lease expiry while the provider request is in flight — recovery reconciles the existing transfer and no second transfer can be submitted', async () => {
    const withdrawalId = await createApprovedWithdrawal(710000);
    const executorId = (await getTestPrisma().user.findUniqueOrThrow({ where: { email: admin3Creds.email } })).id;
    const executeRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId))
      .send({ payoutProvider: 'MOCK' })
      .expect([200, 201]);
    const attemptId = executeRes.body.id as string;

    // 1-2. Worker claims a durable submission lease; the provider request
    // remains in flight (held at the boundary, registered provider-side).
    const mock = app.get(MockPayoutAdapter);
    const reference = expectedReferenceFor(withdrawalId);
    mock.resetCounters();
    const heldRef = new Promise<string>((resolve) => mock.onInitiationHeld(resolve));
    mock.setInitiationHold(true, { registerOnReceipt: true, reference });
    void app.get(PayoutInitiationService).submitOutbox(attemptId).catch(() => undefined);
    expect(await heldRef).toBe(reference);
    const outbox = await getTestPrisma().payoutOutbox.findUniqueOrThrow({ where: { attemptId } });
    expect(outbox.status).toBe('IN_FLIGHT');
    expect(outbox.leaseExpiresAt!.getTime()).toBeGreaterThan(Date.now()); // lease VALID before expiry

    // 7 (during flight). Manual settlement remains blocked.
    const evidence = await makeEvidenceFile(executorId);
    const settleDuringFlight = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_SETTLEMENT', withdrawalId))
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', providerTransferRef: `trf-lease-${rand}`, evidenceFileId: evidence.id });
    expect(settleDuringFlight.status).toBe(409);

    // 3-4. Simulate lease expiry (outbox lease AND the coordination guard's
    // submission lease — the same window in production); start a recovery
    // worker. Whichever worker reclaims the leases, the DURABLE outcome is
    // the adoption.
    await getTestPrisma().payoutOutbox.update({
      where: { id: outbox.id },
      data: { claimedBy: 'expired-lease-worker', claimedAt: new Date(Date.now() - 20 * 60_000), leaseExpiresAt: new Date(Date.now() - 10 * 60_000) },
    });
    await getTestPrisma().$executeRawUnsafe(`UPDATE "PayoutSettlementGuard" SET "claimedUntil" = now() - interval '10 minutes', "updatedAt" = now() WHERE "withdrawalId" = $1`, withdrawalId);
    mock.setInitiationHold(false);
    await app.get(PayoutInitiationService).submitOutbox(attemptId).catch(() => undefined);
    // 5-6. Recovery did NOT assume the transfer was unsuccessful: it consulted
    // the provider (reconciliation-first) and adopted the existing transfer.
    await waitFor(async () => (await getTestPrisma().payoutAttempt.findUnique({ where: { id: attemptId } }))?.providerTransferRef === reference, 'lease-expiry recovery adopts the existing transfer');
    expect(mock.initiationCount(reference)).toBe(1);

    // 8. A second transfer cannot be submitted while the outcome was
    // ambiguous: the durable intent is SUBMITTED — further workers no-op.
    await waitFor(async () => (await getTestPrisma().payoutOutbox.findUnique({ where: { attemptId } }))?.status === 'SUBMITTED', 'the outbox intent is durably SUBMITTED');
    const repeatSummary = await app.get(PayoutInitiationService).submitOutbox(attemptId);
    expect(repeatSummary.action).toBe('ALREADY_SUBMITTED');
    expect(mock.initiationCount(reference)).toBe(1);

    // 9-10. Complete reconciliation; exactly one settlement.
    const attempt = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } });
    const reconciliation = app.get(PayoutReconciliationService);
    const beneficiaryRef = (await getTestPrisma().payoutBeneficiary.findFirstOrThrow({ where: { withdrawalId, provider: 'MOCK' } })).externalRef;
    await reconciliation.apply({
      attemptId,
      source: 'RECONCILIATION_SWEEP' as never,
      verification: { classification: 'SUCCESSFUL' as never, providerStatus: 'success', providerReference: reference, amountMinor: attempt.amount, currency: attempt.currency, beneficiaryRef, evidence: { status: 'success' } },
    });
    const w = await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
    expect(w.status).toBe('PAID');
    expect(w.amount).toBe(710000n);
    expect(await getTestPrisma().ledgerTransaction.count({ where: { reference: `withdrawal:${withdrawalId}` } })).toBe(1);
    expect(await getTestPrisma().payoutSettlementGuard.findUniqueOrThrow({ where: { withdrawalId } }).then((g) => g.mode)).toBe('SETTLED');
  });

  it('v1.0.10 §6.9 (G): duplicate workers on the same outbox item — one authoritative claim, one provider request, repeated reconciliation posts ONE ledger entry', async () => {
    const withdrawalId = await createApprovedWithdrawal(720000);
    const executeRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId))
      .send({ payoutProvider: 'MOCK' })
      .expect([200, 201]);
    const attemptId = executeRes.body.id as string;

    const mock = app.get(MockPayoutAdapter);
    const reference = expectedReferenceFor(withdrawalId);
    mock.resetCounters();
    const heldRef = new Promise<string>((resolve) => mock.onInitiationHeld(resolve));
    mock.setInitiationHold(true, { registerOnReceipt: true, reference });
    // Worker #1 claims the durable submission lease and reaches the provider.
    void app.get(PayoutInitiationService).submitOutbox(attemptId).catch(() => undefined);
    expect(await heldRef).toBe(reference);
    // Worker #2 runs against the SAME outbox item concurrently.
    const workerTwo = await app.get(PayoutInitiationService).submitOutbox(attemptId);
    // Only the lease holder has the authoritative claim; worker #2 cannot acquire it.
    expect(workerTwo.action).toBe('LOOKUP_PENDING');
    expect(JSON.stringify(workerTwo)).toContain('claimed');
    // The provider does NOT receive two independent payout requests, and the
    // same logical payout reference is used.
    expect(mock.initiationCount(reference)).toBe(1);
    expect(await getTestPrisma().payoutAttempt.count({ where: { withdrawalId } })).toBe(1);
    expect(await getTestPrisma().payoutOutbox.count({ where: { withdrawalId } })).toBe(1);

    // Worker #1 completes its submission (whichever worker owns the lease —
    // the DURABLE outcome is what is asserted).
    await mock.releaseHeldInitiation('accept');
    mock.setInitiationHold(false);
    await waitFor(async () => (await getTestPrisma().payoutAttempt.findUnique({ where: { id: attemptId } }))?.providerTransferRef === reference, 'the lease holder persists the acceptance');
    const attempt = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } });
    expect(attempt.providerTransferRef).toBe(reference);
    expect(mock.hasTransfer(reference)).toBe(true);

    // Repeated reconciliation cannot create multiple ledger entries.
    const reconciliation = app.get(PayoutReconciliationService);
    const beneficiaryRef = (await getTestPrisma().payoutBeneficiary.findFirstOrThrow({ where: { withdrawalId, provider: 'MOCK' } })).externalRef;
    const verification = { classification: 'SUCCESSFUL' as never, providerStatus: 'success', providerReference: reference, amountMinor: attempt.amount, currency: attempt.currency, beneficiaryRef, evidence: { status: 'success' } };
    await reconciliation.apply({ attemptId, source: 'RECONCILIATION_SWEEP' as never, verification });
    const replay = await reconciliation.apply({ attemptId, source: 'RECONCILIATION_SWEEP' as never, verification });
    expect(replay.outcome).toBe('MATCHED');
    expect(replay.applied).toBe(false);

    const w = await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
    expect(w.status).toBe('PAID');
    expect(w.amount).toBe(720000n);
    expect(await getTestPrisma().ledgerTransaction.count({ where: { reference: `withdrawal:${withdrawalId}` } })).toBe(1);
    expect(await getTestPrisma().payoutSettlementGuard.findUniqueOrThrow({ where: { withdrawalId } }).then((g) => g.mode)).toBe('SETTLED');
  });

  it('§10: reconciliation replay after settlement is a no-op — the ledger is posted exactly once', async () => {
    const withdrawalId = await createApprovedWithdrawal(750000);
    const executeRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId))
      .send({ payoutProvider: 'MOCK' })
      .expect([200, 201]);
    const attemptId = executeRes.body.id as string;
    const initiation = app.get(PayoutInitiationService);
    await initiation.submitOutbox(attemptId);

    // The MOCK provider's transfer statuses are not part of the classification
    // switch, so the SUCCESSFUL evidence is applied through the authoritative
    // reconciliation service directly (the exact path a real provider's
    // verified success would take). The attempt's persisted executor
    // (initiatedById) is validated by the approval-cycle gate inside.
    const reconciliation = app.get((await import('../src/payouts/payout-reconciliation.service')).PayoutReconciliationService);
    const attempt = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } });
    const beneficiaryRef = (await getTestPrisma().payoutBeneficiary.findFirstOrThrow({ where: { withdrawalId, provider: 'MOCK' } })).externalRef;
    const verification = {
      classification: 'SUCCESSFUL' as never,
      providerStatus: 'success',
      providerReference: attempt.providerTransferRef ?? undefined,
      amountMinor: attempt.amount,
      currency: attempt.currency,
      beneficiaryRef,
      evidence: { status: 'success' },
    };
    await reconciliation.apply({ attemptId, source: 'RECONCILIATION_SWEEP' as never, verification });
    const w = await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
    expect(w.status).toBe('PAID');
    const ledgerAfterFirst = await getTestPrisma().ledgerTransaction.count({ where: { reference: `withdrawal:${withdrawalId}` } });
    expect(ledgerAfterFirst).toBe(1);

    // A stale worker replays the SAME verification — the reconciliation is a
    // no-op (MATCHED, applied=false) and NO second ledger entry appears.
    const replay = await reconciliation.apply({ attemptId, source: 'RECONCILIATION_SWEEP' as never, verification });
    expect(replay.outcome).toBe('MATCHED');
    expect(replay.applied).toBe(false);
    const ledgerAfterReplay = await getTestPrisma().ledgerTransaction.count({ where: { reference: `withdrawal:${withdrawalId}` } });
    expect(ledgerAfterReplay).toBe(1);
  });

  it('v1.0.10 §5.6: final reconciliation validates the LOCKED executor identity on REAL PostgreSQL — a missing or colliding executor blocks settlement', async () => {
    const withdrawalId = await createApprovedWithdrawal(730000);
    const executorId = (await getTestPrisma().user.findUniqueOrThrow({ where: { email: admin3Creds.email } })).id;
    const approvals = await getTestPrisma().withdrawalApproval.findMany({ where: { withdrawalId, status: 'ACTIVE' } });
    const firstApproverId = approvals.find((a) => a.role === 'FIRST_APPROVER')!.approverId;

    const executeRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId))
      .send({ payoutProvider: 'MOCK' })
      .expect([200, 201]);
    const attemptId = executeRes.body.id as string;
    const initiation = app.get(PayoutInitiationService);
    await initiation.submitOutbox(attemptId);
    const reconciliation = app.get(PayoutReconciliationService);
    const beneficiaryRef = (await getTestPrisma().payoutBeneficiary.findFirstOrThrow({ where: { withdrawalId, provider: 'MOCK' } })).externalRef;
    const buildVerification = () =>
      getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } }).then((a) => ({
        classification: 'SUCCESSFUL' as never,
        providerStatus: 'success',
        providerReference: a.providerTransferRef ?? undefined,
        amountMinor: a.amount,
        currency: a.currency,
        beneficiaryRef,
        evidence: { status: 'success' },
      }));

    // CASE 1 — the locked executor is MISSING: settlement is rejected.
    await getTestPrisma().payoutAttempt.update({ where: { id: attemptId }, data: { initiatedById: null } });
    const missingExecutor = await reconciliation.apply({ attemptId, source: 'RECONCILIATION_SWEEP' as never, verification: await buildVerification() });
    expect(missingExecutor.outcome).toBe('INTERNAL_STATE_MISMATCH');
    const blockedAudit = await getTestPrisma().auditLog.findFirstOrThrow({ where: { entityId: withdrawalId, action: 'PAYOUT_SETTLEMENT_BLOCKED_INVALID_APPROVAL_CYCLE' }, orderBy: { createdAt: 'desc' } });
    expect((blockedAudit.metadata as Record<string, unknown>).executorId).toBeNull();
    expect(String((blockedAudit.metadata as Record<string, unknown>).invalidReason)).toContain('executor');
    let w = await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
    expect(w.status).not.toBe('PAID');
    expect(await getTestPrisma().ledgerTransaction.count({ where: { reference: `withdrawal:${withdrawalId}` } })).toBe(0);

    // Reset the durable rows for the next case (the blocked run moved the
    // attempt to MANUAL_REVIEW and the withdrawal to REQUIRES_RECONCILIATION).
    await getTestPrisma().payoutAttempt.update({ where: { id: attemptId }, data: { status: 'PROVIDER_ACCEPTED', classification: 'PENDING', initiatedById: executorId } });
    await getTestPrisma().withdrawal.update({ where: { id: withdrawalId }, data: { status: 'PROCESSING' } });

    // CASE 2 — the persisted executor COLLIDES with the first approver: the
    // four-person separation fails on the authoritative row.
    await getTestPrisma().payoutAttempt.update({ where: { id: attemptId }, data: { initiatedById: firstApproverId } });
    const collidingExecutor = await reconciliation.apply({ attemptId, source: 'RECONCILIATION_SWEEP' as never, verification: await buildVerification() });
    expect(collidingExecutor.outcome).toBe('INTERNAL_STATE_MISMATCH');
    w = await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
    expect(w.status).not.toBe('PAID');

    // CASE 3 — the persisted executor is the authorized fourth person again:
    // the locked identity authorizes the settlement and the audit event
    // records THE LOCKED identity (proof the decision used the locked row).
    await getTestPrisma().payoutAttempt.update({ where: { id: attemptId }, data: { status: 'PROVIDER_ACCEPTED', classification: 'PENDING', initiatedById: executorId } });
    await getTestPrisma().withdrawal.update({ where: { id: withdrawalId }, data: { status: 'PROCESSING' } });
    const settled = await reconciliation.apply({ attemptId, source: 'RECONCILIATION_SWEEP' as never, verification: await buildVerification() });
    expect(['PROVIDER_SUCCESS_INTERNAL_PENDING', 'MATCHED']).toContain(settled.outcome);
    w = await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
    expect(w.status).toBe('PAID');
    const settledAudit = await getTestPrisma().auditLog.findFirstOrThrow({ where: { entityId: withdrawalId, action: 'PAYOUT_SETTLED_PROVIDER_VERIFIED' }, orderBy: { createdAt: 'desc' } });
    expect((settledAudit.metadata as Record<string, unknown>).executorId).toBe(executorId);
    expect(await getTestPrisma().ledgerTransaction.count({ where: { reference: `withdrawal:${withdrawalId}` } })).toBe(1);
  });

  it('§12.3: an expired IN_FLIGHT lease is reclaimed SAFELY — the provider is consulted BEFORE any resubmission (no duplicate transfer)', async () => {
    const withdrawalId = await createApprovedWithdrawal(600000);
    // Execute a REAL (mock) provider payout through the durable outbox pipeline.
    const executeRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId))
      .send({ payoutProvider: 'MOCK' })
      .expect([200, 201]);
    const attemptId = executeRes.body.id as string;

    const submission = await app.get(PayoutInitiationService).submitOutbox(attemptId);
    expect(['SUBMITTED', 'ACCEPTED']).toContain(submission.action);
    const attemptAfterSubmit = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } });
    expect(attemptAfterSubmit.providerTransferRef).toBeTruthy();

    // Simulate a crashed worker: the outbox is IN_FLIGHT with an expired
    // lease even though the provider ALREADY accepted the transfer.
    const outbox = await getTestPrisma().payoutOutbox.findUniqueOrThrow({ where: { attemptId } });
    await getTestPrisma().payoutOutbox.update({
      where: { id: outbox.id },
      data: {
        status: 'IN_FLIGHT',
        claimedBy: 'dead-worker',
        claimedAt: new Date(Date.now() - 20 * 60_000),
        leaseExpiresAt: new Date(Date.now() - 10 * 60_000),
        submittedAt: null,
        processedAt: null,
      },
    });
    // Also rewind the attempt to INITIATED so a naive recovery would
    // resubmit; the SAFE recovery must adopt the existing provider identity.
    await getTestPrisma().payoutAttempt.update({ where: { id: attemptId }, data: { status: 'INITIATED' } });

    const summary = await app.get(PayoutInitiationService).submitOutbox(attemptId);
    expect(summary.action).toBe('ALREADY_SUBMITTED');

    const attemptAfterRecovery = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } });
    expect(attemptAfterRecovery.providerTransferRef).toBe(attemptAfterSubmit.providerTransferRef);
    expect(attemptAfterRecovery.status).toBe('PROVIDER_ACCEPTED');
    const outboxAfter = await getTestPrisma().payoutOutbox.findUniqueOrThrow({ where: { id: outbox.id } });
    expect(outboxAfter.status).toBe('SUBMITTED');
    expect(outboxAfter.recoveryAttempts).toBe(1);
    expect(outboxAfter.claimedBy).not.toBe('dead-worker');
  });

  it('§12.3: an expired lease on an intent the provider never received is reclaimed and submitted exactly once', async () => {
    const withdrawalId = await createApprovedWithdrawal(700000);
    const executeRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId))
      .send({ payoutProvider: 'MOCK' })
      .expect([200, 201]);
    const attemptId = executeRes.body.id as string;

    // The intent was committed but the worker crashed BEFORE the provider call:
    // outbox IN_FLIGHT with an expired lease, attempt INITIATED, no provider
    // identity, and the mock provider has NO transfer for the reference.
    const outbox = await getTestPrisma().payoutOutbox.findUniqueOrThrow({ where: { attemptId } });
    await getTestPrisma().payoutOutbox.update({
      where: { id: outbox.id },
      data: {
        status: 'IN_FLIGHT',
        claimedBy: 'dead-worker',
        claimedAt: new Date(Date.now() - 20 * 60_000),
        leaseExpiresAt: new Date(Date.now() - 10 * 60_000),
      },
    });

    const summary = await app.get(PayoutInitiationService).submitOutbox(attemptId);
    expect(['SUBMITTED', 'ACCEPTED']).toContain(summary.action);

    // Exactly ONE attempt row and ONE provider identity — no duplicate transfer.
    const attempts = await getTestPrisma().payoutAttempt.count({ where: { withdrawalId } });
    expect(attempts).toBe(1);
    const attempt = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } });
    expect(attempt.providerTransferRef).toBeTruthy();
    const outboxAfter = await getTestPrisma().payoutOutbox.findUniqueOrThrow({ where: { id: outbox.id } });
    expect(outboxAfter.status).toBe('SUBMITTED');
    expect(outboxAfter.recoveryAttempts).toBe(1);
  });

  it('§8.2: an in-progress reversal observed on a real attempt is recorded in the reversal lifecycle — the attempt is NOT terminal', async () => {
    const withdrawalId = await createApprovedWithdrawal(800000);
    const executeRes = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', await freshMfa(admin3Token, 'PAYOUT_EXECUTION', withdrawalId))
      .send({ payoutProvider: 'MOCK' })
      .expect([200, 201]);
    const attemptId = executeRes.body.id as string;
    const initiation = app.get(PayoutInitiationService);
    await initiation.submitOutbox(attemptId);
    // Verify through the pipeline so the attempt reaches PENDING (mock status).
    const withdrawalsService = app.get((await import('../src/withdrawals/withdrawals.service')).WithdrawalsService);
    await withdrawalsService.verifyPayoutAttempt(attemptId, { id: admin3Token ? '' : '', role: 'ADMIN' } as never).catch(() => undefined);

    // Drive the reconciliation service DIRECTLY with an in-progress reversal
    // classification. The attempt's provider is switched to FLUTTERWAVE in
    // the fixture because the MOCK adapter cannot produce reversal statuses —
    // reverse_initiated is Flutterwave-specific lifecycle semantics (§8.2).
    await getTestPrisma().payoutAttempt.update({ where: { id: attemptId }, data: { provider: 'FLUTTERWAVE' } });
    const reconciliation = app.get((await import('../src/payouts/payout-reconciliation.service')).PayoutReconciliationService);
    const result = await reconciliation.apply({
      attemptId,
      source: 'RECONCILIATION_SWEEP',
      verification: {
        classification: 'REVERSAL_IN_PROGRESS',
        providerStatus: 'reverse_initiated',
        providerReference: (await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } })).providerTransferRef ?? undefined,
      },
    });
    expect(result.outcome).toBe('PROVIDER_REVERSAL_IN_PROGRESS');

    const attempt = await getTestPrisma().payoutAttempt.findUniqueOrThrow({ where: { id: attemptId } });
    expect(attempt.reversalState).toBe('INITIATED');
    expect(attempt.classification).toBe('REVERSAL_IN_PROGRESS');
    expect(attempt.status).not.toBe('REVERSED'); // in-progress reversal is NEVER terminal
    const w = await getTestPrisma().withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
    expect(w.status).not.toBe('REVERSED');
    // A controlled recovery decision was escalated.
    const reviewCase = await getTestPrisma().manualReviewCase.findFirst({ where: { attemptId, category: 'PROVIDER_REVERSAL' } });
    expect(reviewCase).toBeTruthy();
  });
});
