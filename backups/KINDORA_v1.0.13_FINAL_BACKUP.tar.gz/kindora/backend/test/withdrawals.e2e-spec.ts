import request from 'supertest';
import type { NestExpressApplication } from '@nestjs/platform-express';
import { closeTestApp, createTestApp, getTestPrisma, maybeDescribe } from './setup';
import { base32Decode, hotp, TOTP_STEP_SECONDS } from '../src/mfa/totp.util';

// MFA challenge exchanges legitimately wait out TOTP windows (30s each) in replay-race scenarios.
jest.setTimeout(240_000);

/**
 * Withdrawal authorization & financial-integrity integration tests (v1.0.4).
 *
 * Covered invariants (REAL PostgreSQL + REAL Redis, PROVIDER_MODE=mock):
 *  - withdrawal reads/writes are manager-only: plain donors get 403 on the
 *    available balance and on payout requests;
 *  - bank destination details are FIELD-MASKED for non-entitled viewers
 *    (donor sees `****6789`, requester sees the full account number);
 *  - organizers cannot call admin routes (roles guard);
 *  - the legacy mark-paid / mark-failed / mark-processing endpoints are GONE
 *    (404) — no payout-state manipulation route exists;
 *  - every admin payout action requires FRESH MFA (real TOTP enrollment +
 *    single-use challenge against real Redis, fail-closed);
 *  - requester-self-approval is forbidden EVEN for admins;
 *  - dual approval (mode ALL): a second DISTINCT administrator must approve,
 *    the second approver cannot execute the payout, and settlement requires
 *    a third distinct executor with a registered private evidence file;
 *  - settlement posts the ledger EXACTLY once (unique `withdrawal:<id>`
 *    reference: stale-state replay hits P2002 -> 409, never a double payout);
 *  - concurrent overdraw: two parallel 800k requests against a 1,000,000
 *    balance serialise on the campaign row lock — exactly one succeeds and
 *    the reservations never exceed the genuinely available balance.
 */

const rand = Math.random().toString(36).slice(2, 10);
const donorCreds = {
  email: `wd-donor-${rand}@kindora.test`,
  password: 'WdDonorPass1!',
  firstName: 'Dami',
  lastName: 'Donor',
};
const organizerCreds = {
  email: `wd-organizer-${rand}@kindora.test`,
  password: 'WdOrganizer1!',
  firstName: 'Chidi',
  lastName: 'Organizer',
};
const admin2Creds = {
  email: `wd-admin2-${rand}@kindora.test`,
  password: 'WdAdmin2Pass1!',
  firstName: 'Sade',
  lastName: 'Second',
};
const admin3Creds = {
  email: `wd-admin3-${rand}@kindora.test`,
  password: 'WdAdmin3Pass1!',
  firstName: 'Tola',
  lastName: 'Third',
};
const ADMIN_EMAIL = 'admin@kindora.com';
const ADMIN_PASSWORD = process.env.SEED_ADMIN_PASSWORD ?? 'Kindora-Admin-2026!';

const STORY =
  'This campaign exists to verify the withdrawal control plane end to end. It funds the ledger through a real ' +
  'mock-provider donation and then exercises authorization, masking, separation of duties, exactly-once settlement ' +
  'and the concurrent-overdraw guarantee. All amounts are minor units tracked by the double-entry ledger.';

const DESTINATION = { accountName: 'Chidi Organizer', accountNumber: '0123456789', bankName: 'Test Bank' };

maybeDescribe('Withdrawals (e2e, authorization + integrity)', () => {
  let app: NestExpressApplication;
  let donorToken = '';
  let organizerToken = '';
  let adminToken = '';
  let admin2Token = '';
  let admin3Token = '';
  let admin3Id = '';
  let campaignId = '';
  let campaignSlug = '';
  let withdrawalId = '';

  async function createApprovedCampaign(title: string): Promise<{ id: string; slug: string }> {
    const created = await request(app.getHttpServer())
      .post('/api/v1/campaigns')
      .set('Authorization', `Bearer ${organizerToken}`)
      .send({
        title,
        excerpt: 'Withdrawal control-plane suite.',
        story: STORY,
        categorySlug: 'education',
        country: 'Nigeria',
        targetAmountMajor: 1000000,
        currency: 'NGN',
      })
      .expect(201);
    const { id, slug } = created.body.campaign as { id: string; slug: string };
    await request(app.getHttpServer())
      .post(`/api/v1/campaigns/${id}/submit`)
      .set('Authorization', `Bearer ${organizerToken}`)
      .expect([200, 201]);
    await request(app.getHttpServer())
      .post(`/api/v1/admin/campaigns/${id}/approve`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ note: 'withdrawal suite' })
      .expect([200, 201]);
    return { id, slug };
  }

  /** Donates via the MOCK provider and completes it through the status endpoint. */
  async function donateAndVerify(slug: string, amountMinor: number): Promise<void> {
    const donation = await request(app.getHttpServer())
      .post('/api/v1/donations')
      .set('Authorization', `Bearer ${donorToken}`)
      .send({ campaignSlug: slug, amountMinor, provider: 'MOCK' })
      .expect(201);
    const publicRef = donation.body.donation.publicRef as string;
    // The URL label must be a public provider name; the record decides the adapter.
    const status = await request(app.getHttpServer()).get(`/api/v1/donations/status/PAYSTACK/${publicRef}`).expect(200);
    expect(status.body.status).toBe('SUCCEEDED');
  }

  /**
   * REAL fresh-MFA flow against real Redis (fail-closed): enroll (idempotent),
   * confirm with a current TOTP code, exchange the next step's code for a
   * single-use challenge token. Returns the x-mfa-challenge header value.
   */
  function totpCode(secretBase32: string, stepOffset = 0): string {
    const buf = base32Decode(secretBase32.replace(/=+$/, ''));
    const counter = BigInt(Math.floor(Date.now() / 1000 / TOTP_STEP_SECONDS)) + BigInt(stepOffset);
    return hotp(buf, counter);
  }

  // Enrollment secret per bearer token — the API returns it exactly once by
  // design, so the helper caches it to exchange later challenge codes for the
  // SAME account (freshMfa is called multiple times per admin in this suite).
  const enrolledSecrets = new Map<string, string>();

  // Exchange the CURRENT counter's code (or the next counter's) for a single-use
  // challenge token. The server accepts only counters within ±1 of now and a
  // verified counter is replay-locked — so when enroll+earlier challenges already
  // consumed both verifiable counters of this 30s window, the helper waits for
  // the next window instead of hammering (bounded to 3 windows).
  async function exchangeChallenge(bearer: string, purpose: string, scope: string, secretBase32: string): Promise<string> {
    for (let win = 0; win < 3; win++) {
      for (const off of [0, 1]) {
        const attempt = await request(app.getHttpServer())
          .post('/api/v1/mfa/challenge')
          .set('Authorization', `Bearer ${bearer}`)
          .send({ purpose, scope, code: totpCode(secretBase32, off) });
        if (attempt.status === 200 || attempt.status === 201) {
          return attempt.body.challengeToken as string;
        }
        // 403 replay/window rejections and rare 400 boundary races are both
        // TRANSIENT for the helper: wait out the TOTP window and retry with
        // the next window's counter (bounded — never loops forever).
      }
      // Wait out the current TOTP window; the next window offers a fresh counter.
      await new Promise((r) => setTimeout(r, 30000 - (Date.now() % 30000) + 250));
    }
    throw new Error('No usable TOTP counter for MFA challenge after 3 windows');
  }

  async function freshMfa(bearer: string, purpose: string, scope: string): Promise<string> {
    const status = await request(app.getHttpServer())
      .get('/api/v1/mfa/status')
      .set('Authorization', `Bearer ${bearer}`)
      .expect(200);
    let secret = enrolledSecrets.get(bearer);
    if (!status.body.active) {
      const enroll = await request(app.getHttpServer())
        .post('/api/v1/mfa/enroll')
        .set('Authorization', `Bearer ${bearer}`)
        .expect([200, 201]);
      secret = enroll.body.secret as string;
      enrolledSecrets.set(bearer, secret);
      await request(app.getHttpServer())
        .post('/api/v1/mfa/confirm')
        .set('Authorization', `Bearer ${bearer}`)
        .send({ code: totpCode(secret) })
        .expect([200, 201]);
    } else if (!secret) {
      // Active but this process never saw the secret (persistent DB from a
      // previous run). The secret is not retrievable by design — fail loudly.
      throw new Error(
        'Account already has active MFA whose enrollment secret this test run never received — use a fresh account for MFA-bound assertions',
      );
    }
    return exchangeChallenge(bearer, purpose, scope, secret!);
  }

  /**
   * Registers a private, scanned, PAYOUT_EVIDENCE StoredFile directly in the
   * file registry (the upload flow itself is covered by storage.e2e-spec.ts).
   * Evidence validation (ownership, kind, scan verdict, visibility, binding)
   * runs in the service under test.
   */
  async function makeEvidenceFile(uploaderId: string) {
    return getTestPrisma().storedFile.create({
      data: {
        key: `evidence/withdrawal-suite-${rand}-${Math.random().toString(36).slice(2, 8)}.pdf`,
        kind: 'PAYOUT_EVIDENCE',
        visibility: 'PRIVATE',
        status: 'APPROVED',
        scanVerdict: 'CLEAN',
        fileName: 'bank-transfer-receipt.pdf',
        contentType: 'application/pdf',
        sizeBytes: 2048n,
        uploaderId,
      },
    });
  }

  beforeAll(async () => {
    app = await createTestApp();

    // MFA enrollment secrets are intentionally unretrievable; when this suite
    // runs against a persistent database, reset the accounts' credentials so
    // THIS process can enroll fresh (secrets below are received exactly once).
    await getTestPrisma().mfaCredential.deleteMany({
      where: { user: { email: { in: [ADMIN_EMAIL, admin2Creds.email, admin3Creds.email] } } },
    });

    // Users. admin2 starts as a normal user and is promoted to ADMIN directly
    // in the database (there is no public role-escalation API by design).
    await request(app.getHttpServer()).post('/api/v1/auth/register').send(donorCreds).expect(201);
    await request(app.getHttpServer()).post('/api/v1/auth/register').send(organizerCreds).expect(201);
    await request(app.getHttpServer()).post('/api/v1/auth/register').send(admin2Creds).expect(201);
    await request(app.getHttpServer()).post('/api/v1/auth/register').send(admin3Creds).expect(201);
    await getTestPrisma().user.update({ where: { email: admin2Creds.email }, data: { role: 'ADMIN' } });
    await getTestPrisma().user.update({ where: { email: admin3Creds.email }, data: { role: 'ADMIN' } });
    await request(app.getHttpServer())
      .post('/api/v1/auth/dev/complete-verification')
      .send({ email: organizerCreds.email })
      .expect(200)
      .expect({ verified: true });

    const donorLogin = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: donorCreds.email, password: donorCreds.password })
      .expect([200, 201]);
    donorToken = donorLogin.body.accessToken;

    const organizerLogin = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: organizerCreds.email, password: organizerCreds.password })
      .expect([200, 201]);
    organizerToken = organizerLogin.body.accessToken;

    const admin2Login = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: admin2Creds.email, password: admin2Creds.password })
      .expect([200, 201]);
    admin2Token = admin2Login.body.accessToken;

    const admin3Login = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: admin3Creds.email, password: admin3Creds.password })
      .expect([200, 201]);
    admin3Token = admin3Login.body.accessToken;
    admin3Id = (await getTestPrisma().user.findUnique({ where: { email: admin3Creds.email } }))!.id;

    const adminLogin = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD })
      .expect([200, 201]);
    adminToken = adminLogin.body.accessToken;

    const campaign = await createApprovedCampaign(`Withdrawal Suite Campaign ${rand}`);
    campaignId = campaign.id;
    campaignSlug = campaign.slug;

    await donateAndVerify(campaignSlug, 2500000);
  });

  afterAll(async () => {
    await closeTestApp();
  });

  it('donors are not campaign managers: available balance and payout requests are 403', async () => {
    await request(app.getHttpServer())
      .get(`/api/v1/withdrawals/available/${campaignId}`)
      .set('Authorization', `Bearer ${donorToken}`)
      .expect(403);

    await request(app.getHttpServer())
      .post('/api/v1/withdrawals')
      .set('Authorization', `Bearer ${donorToken}`)
      .send({ campaignId, amountMinor: 100000, method: 'BANK', destination: DESTINATION })
      .expect(403);
  });

  it('the organizer sees the full ledger balance available for payout', async () => {
    const res = await request(app.getHttpServer())
      .get(`/api/v1/withdrawals/available/${campaignId}`)
      .set('Authorization', `Bearer ${organizerToken}`)
      .expect(200);
    expect(res.body).toMatchObject({ currency: 'NGN', availableMinor: '2500000' });
  });

  it('organizer requests a withdrawal; non-entitled viewers only ever see masked bank details', async () => {
    const created = await request(app.getHttpServer())
      .post('/api/v1/withdrawals')
      .set('Authorization', `Bearer ${organizerToken}`)
      .send({ campaignId, amountMinor: 1000000, method: 'BANK', destination: DESTINATION })
      .expect(201);
    withdrawalId = created.body.id;
    expect(created.body.status).toBe('PENDING');
    expect(created.body.amount).toBe('1000000');

    // Donor (authenticated, NOT entitled): destination must be masked.
    const donorView = await request(app.getHttpServer())
      .get(`/api/v1/withdrawals/${withdrawalId}`)
      .set('Authorization', `Bearer ${donorToken}`)
      .expect(200);
    expect(donorView.body.viewerCanSeeFullDetails).toBe(false);
    expect(donorView.body.destination.accountNumber).toBe('****6789');
    expect(JSON.stringify(donorView.body)).not.toContain('0123456789');

    // Requester sees the full destination.
    const organizerView = await request(app.getHttpServer())
      .get(`/api/v1/withdrawals/${withdrawalId}`)
      .set('Authorization', `Bearer ${organizerToken}`)
      .expect(200);
    expect(organizerView.body.viewerCanSeeFullDetails).toBe(true);
    expect(organizerView.body.destination.accountNumber).toBe('0123456789');
  });

  it('the organizer cannot call admin routes on withdrawals (403 roles guard)', async () => {
    const res = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/approve`)
      .set('Authorization', `Bearer ${organizerToken}`)
      .expect(403);
    expect(JSON.stringify(res.body)).toContain('role');
  });

  it('requester-self-approval is forbidden even for admins (separation of duties)', async () => {
    // An admin may CREATE a withdrawal for a campaign (admins pass the
    // manager check), but must never approve or pay their own request.
    const selfRequested = await request(app.getHttpServer())
      .post('/api/v1/withdrawals')
      .set('Authorization', `Bearer ${admin2Token}`)
      .send({ campaignId, amountMinor: 500000, method: 'BANK', destination: DESTINATION })
      .expect(201);
    const selfId = selfRequested.body.id as string;

    // v1.0.7 §8.4 — fail-closed step-up FIRST: an approval attempt without a
    // fresh MFA challenge is rejected with the MFA error even when the caller
    // would also violate separation of duties (the guard cannot leak the
    // separation decision to a session that has not proven freshness).
    const approveNoMfa = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${selfId}/approve`)
      .set('Authorization', `Bearer ${admin2Token}`)
      .expect(403);
    expect(approveNoMfa.body.message).toContain('Fresh MFA verification required');

    // Separation of duties with a VALID fresh MFA challenge: the requester is
    // still forbidden from approving their own withdrawal.
    const approve = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${selfId}/approve`)
      .set('Authorization', `Bearer ${admin2Token}`)
      .set('x-mfa-challenge', await freshMfa(admin2Token, 'PAYOUT_FIRST_APPROVAL', selfId))
      .expect(403);
    expect(approve.body.message).toContain('cannot approve');

    // Settlement is forbidden for the requester even with a valid MFA challenge.
    const settle = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${selfId}/settle`)
      .set('Authorization', `Bearer ${admin2Token}`)
      .set('x-mfa-challenge', await freshMfa(admin2Token, 'PAYOUT_SETTLEMENT', selfId))
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', providerTransferRef: `self-${rand}`, evidenceFileId: 'evidence-file-id' })
      .expect(403);
    expect(settle.body.message).toContain('cannot settle');

    // Clean up the reservation so the ledger arithmetic stays simple.
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${selfId}/cancel`)
      .set('Authorization', `Bearer ${admin2Token}`)
      .expect([200, 201])
      .expect({ ok: true });
  });

  it('legacy payout-state manipulation endpoints are GONE (404)', async () => {
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/mark-paid`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', providerTransferRef: `gone-${rand}` })
      .expect(404);
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/mark-failed`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ note: 'force fail attempt' })
      .expect(404);
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/mark-processing`)
      .set('Authorization', `Bearer ${adminToken}`)
      .expect(404);
  });

  it('payout actions without fresh MFA are rejected (fail-closed step-up)', async () => {
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/approve`)
      .set('Authorization', `Bearer ${admin2Token}`)
      .expect(403);
    const noScope = await request(app.getHttpServer())
      .post(`/api/v1/mfa/challenge`)
      .set('Authorization', `Bearer ${admin2Token}`)
      .send({ purpose: 'PAYOUT_FIRST_APPROVAL', code: '000000' })
      .expect([400, 401, 403]);
    void noScope;
  });

  it('a SECOND admin approves the withdrawal with fresh MFA (dual approval mode ALL)', async () => {
    const token = await freshMfa(admin2Token, 'PAYOUT_FIRST_APPROVAL', withdrawalId);
    const res = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/approve`)
      .set('Authorization', `Bearer ${admin2Token}`)
      .set('x-mfa-challenge', token)
      .expect([200, 201]);
    expect(res.body.status).toBe('APPROVED');
    expect(res.body.dualApprovalRequired).toBe(true);

    // The first approver CANNOT also be the second approver (loophole removed).
    const sameAdminToken = await freshMfa(admin2Token, 'PAYOUT_SECOND_APPROVAL', withdrawalId);
    const selfSecond = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/second-approval`)
      .set('Authorization', `Bearer ${admin2Token}`)
      .set('x-mfa-challenge', sameAdminToken)
      .send({ note: 'attempt to double-approve' })
      .expect(403);
    expect(selfSecond.body.message).toContain('first approver cannot also be the second approver');

    // A DISTINCT second administrator approves with fresh MFA.
    const token2 = await freshMfa(admin3Token, 'PAYOUT_SECOND_APPROVAL', withdrawalId);
    const second = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/second-approval`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', token2)
      .send({ note: 'second approval' })
      .expect([200, 201]);
    expect(second.body.secondApprovedById).toBe(admin3Id);
  });

  it('settlement requires a registered private evidence file and a FOURTH distinct executor', async () => {
    // The SECOND approver (admin3) cannot execute the payout.
    const fileForSecond = await makeEvidenceFile(admin3Id);
    const secondExecToken = await freshMfa(admin3Token, 'PAYOUT_SETTLEMENT', withdrawalId);
    const execAttempt = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', secondExecToken)
      .send({
        payoutProvider: 'MANUAL_BANK_TRANSFER',
        providerTransferRef: `trf-exec-${rand}`,
        evidenceFileId: fileForSecond.id,
      })
      .expect(403);
    expect(execAttempt.body.message).toContain('second approver cannot execute');

    // v1.0.7 §8.2 — the FIRST approver (admin2) cannot execute either: the
    // executor must be a fourth identity distinct from requester AND both
    // approvers (the v1.0.6 exception for the first approver is removed).
    const fileForFirst = await makeEvidenceFile(
      (await getTestPrisma().user.findUnique({ where: { email: admin2Creds.email } }))!.id,
    );
    const firstExecToken = await freshMfa(admin2Token, 'PAYOUT_SETTLEMENT', withdrawalId);
    const firstExecAttempt = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
      .set('Authorization', `Bearer ${admin2Token}`)
      .set('x-mfa-challenge', firstExecToken)
      .send({
        payoutProvider: 'MANUAL_BANK_TRANSFER',
        providerTransferRef: `trf-exec2-${rand}`,
        evidenceFileId: fileForFirst.id,
      })
      .expect(403);
    expect(firstExecAttempt.body.message).toContain('first approver cannot execute');

    // A FOURTH distinct administrator (the seed admin) with their own valid
    // evidence file settles successfully. v1.0.9 §5.1 — the TWO-STEP protocol:
    // the executor first authorizes the manual payout intent (binding the
    // immutable manual approval snapshot on both approvals), then settles.
    const intentToken = await freshMfa(adminToken, 'PAYOUT_EXECUTION', withdrawalId);
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
      .set('Authorization', `Bearer ${adminToken}`)
      .set('x-mfa-challenge', intentToken)
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', note: 'intent authorized by the fourth identity' })
      .expect([200, 201]);
    const evidence = await makeEvidenceFile(
      (await getTestPrisma().user.findUnique({ where: { email: ADMIN_EMAIL } }))!.id,
    );
    const settleToken = await freshMfa(adminToken, 'PAYOUT_SETTLEMENT', withdrawalId);
    const paid = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
      .set('Authorization', `Bearer ${adminToken}`)
      .set('x-mfa-challenge', settleToken)
      .send({
        payoutProvider: 'MANUAL_BANK_TRANSFER',
        providerTransferRef: `trf-${rand}`,
        payoutProviderTxnId: `txn-${rand}`,
        evidenceFileId: evidence.id,
      })
      .expect([200, 201]);
    expect(paid.body.status).toBe('PAID');
    expect(paid.body.providerTransferRef).toBe(`trf-${rand}`);

    // Exactly one ledger posting for the payout.
    const postings = await getTestPrisma().ledgerTransaction.findMany({ where: { reference: `withdrawal:${withdrawalId}` } });
    expect(postings).toHaveLength(1);
    expect(postings[0].type).toBe('WITHDRAWAL');

    // Arbitrary external evidence URLs are REJECTED for new settlements.
    const legacyUrlAttempt = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
      .set('Authorization', `Bearer ${adminToken}`)
      .set('x-mfa-challenge', await freshMfa(adminToken, 'PAYOUT_SETTLEMENT', withdrawalId))
      .send({
        payoutProvider: 'MANUAL_BANK_TRANSFER',
        providerTransferRef: `trf-${rand}-2`,
        evidenceUrl: 'https://evil.example.com/receipt.pdf',
      })
      .expect(400);
    expect(JSON.stringify(legacyUrlAttempt.body)).toContain('evidenceFileId');

    // Sequential second settlement: state is PAID, transition refused.
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
      .set('Authorization', `Bearer ${adminToken}`)
      .set('x-mfa-challenge', await freshMfa(adminToken, 'PAYOUT_SETTLEMENT', withdrawalId))
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', providerTransferRef: `trf-${rand}-3`, evidenceFileId: evidence.id })
      .expect(400);

    // Stale-state replay (as if the first settlement had rolled back its
    // state change but not its ledger commit): unique ledger reference
    // `withdrawal:<id>` turns the race into 409 — never a double payout.
    await getTestPrisma().withdrawal.update({ where: { id: withdrawalId }, data: { status: 'APPROVED' } });
    const replay = await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
      .set('Authorization', `Bearer ${adminToken}`)
      .set('x-mfa-challenge', await freshMfa(adminToken, 'PAYOUT_SETTLEMENT', withdrawalId))
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', providerTransferRef: `trf-${rand}-4`, evidenceFileId: evidence.id })
      .expect(409);
    // v1.0.9 — the durable coordination guard (SETTLED is terminal) is the
    // FIRST line of defense and refuses the replay; the unique ledger
    // reference `withdrawal:<id>` remains the deeper exactly-once barrier.
    expect(replay.body.message).toMatch(/already been settled|settlement path is active/);
    expect(await getTestPrisma().ledgerTransaction.count({ where: { reference: `withdrawal:${withdrawalId}` } })).toBe(1);

    // Restore the settled state (the failed replay rolled back).
    await getTestPrisma().withdrawal.update({ where: { id: withdrawalId }, data: { status: 'PAID' } });
  });

  it('an MFA challenge bound to one withdrawal cannot authorize another', async () => {
    // Create + approve a second withdrawal on the overdraw-race campaign below,
    // then prove the scope binding: challenge for THIS withdrawal, header used
    // against ANOTHER withdrawal -> 403.
    const campaign = await createApprovedCampaign(`Scope Binding Campaign ${rand}`);
    await donateAndVerify(campaign.slug, 400000);
    const created = await request(app.getHttpServer())
      .post('/api/v1/withdrawals')
      .set('Authorization', `Bearer ${organizerToken}`)
      .send({ campaignId: campaign.id, amountMinor: 200000, method: 'BANK', destination: DESTINATION })
      .expect(201);
    const otherId = created.body.id as string;

    const otherToken = await freshMfa(admin2Token, 'PAYOUT_FIRST_APPROVAL', otherId);
    // Use the challenge for the WRONG withdrawal id.
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/approve`)
      .set('Authorization', `Bearer ${admin2Token}`)
      .set('x-mfa-challenge', otherToken)
      .expect(403);
  });

  it('available balance reflects the posted payout (reservation released, liability debited)', async () => {
    const res = await request(app.getHttpServer())
      .get(`/api/v1/withdrawals/available/${campaignId}`)
      .set('Authorization', `Bearer ${organizerToken}`)
      .expect(200);
    expect(res.body.availableMinor).toBe('1500000');
  });

  it('concurrent withdrawal requests cannot overdraw: exactly one of two 800k requests succeeds', async () => {
    // Fresh campaign with a 1,000,000 balance.
    const campaign = await createApprovedCampaign(`Overdraw Race Campaign ${rand}`);
    await donateAndVerify(campaign.slug, 1000000);
    const before = await request(app.getHttpServer())
      .get(`/api/v1/withdrawals/available/${campaign.id}`)
      .set('Authorization', `Bearer ${organizerToken}`)
      .expect(200);
    expect(before.body.availableMinor).toBe('1000000');

    const attempt = () =>
      request(app.getHttpServer())
        .post('/api/v1/withdrawals')
        .set('Authorization', `Bearer ${organizerToken}`)
        .send({ campaignId: campaign.id, amountMinor: 800000, method: 'BANK', destination: DESTINATION });

    // Both requests race: they serialise on the campaign row lock inside the
    // reservation transaction, so the loser sees the winner's reservation.
    const [first, second] = await Promise.all([attempt(), attempt()]);
    const statuses = [first.status, second.status].sort((a, b) => a - b);
    expect(statuses).toEqual([201, 400]);
    const loser = first.status === 400 ? first : second;
    expect(JSON.stringify(loser.body)).toContain('exceeds the available balance');

    // Exactly one reservation exists and the remaining availability is exact.
    const reserved = await getTestPrisma().withdrawal.aggregate({
      where: { campaignId: campaign.id, status: { in: ['PENDING', 'UNDER_REVIEW', 'APPROVED', 'PROCESSING', 'REQUIRES_INFORMATION'] } },
      _sum: { amount: true },
    });
    expect(reserved._sum.amount ?? 0n).toBe(800000n); // sum of reservations <= available

    const after = await request(app.getHttpServer())
      .get(`/api/v1/withdrawals/available/${campaign.id}`)
      .set('Authorization', `Bearer ${organizerToken}`)
      .expect(200);
    expect(after.body.availableMinor).toBe('200000');
  });
});
