import { createHmac } from 'node:crypto';
import request from 'supertest';
import type { NestExpressApplication } from '@nestjs/platform-express';
import { closeTestApp, createTestApp, getTestPrisma, maybeDescribe } from './setup';
import { base32Decode, hotp, TOTP_STEP_SECONDS } from '../src/mfa/totp.util';

// MFA challenge exchanges legitimately wait out TOTP windows (30s each) in replay-race scenarios.
jest.setTimeout(240_000);

// The paystack webhook endpoint verifies HMAC-SHA512 signatures over the raw
// body with the REAL verifier (PaymentsService.adapterFor only swaps the MOCK
// provider, not PAYSTACK). Set a known test secret BEFORE the app boots and
// sign the replayed delivery below so signature verification is exercised
// for real instead of being stubbed away.
process.env.PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY ?? 'sk_test_kindora_money_path_replay';

const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET_KEY;

/** Signs a webhook payload exactly the way Paystack does (HMAC-SHA512 of the raw body). */
function signedPaystack(payload: Record<string, unknown>): { body: string; headers: Record<string, string> } {
  const body = JSON.stringify(payload);
  return {
    body,
    headers: { 'Content-Type': 'application/json', 'x-paystack-signature': createHmac('sha512', PAYSTACK_SECRET).update(body).digest('hex') },
  };
}

/**
 * KINDORA end-to-end money-path integration test (REAL PostgreSQL +
 * PROVIDER_MODE=mock). Mirrors scripts/e2e-smoke.mjs exactly:
 *
 *   register -> login -> dev/complete-verification -> create+submit campaign
 *   -> admin approve -> donate (mock) -> server-side verify -> webhook replay
 *   -> ledger + balances -> withdrawal request -> dual approval (3 distinct
 *   admins, fresh MFA) -> settlement with registered evidence file
 *   -> public ledger feed.
 *
 * Run: RUN_INTEGRATION=1 DATABASE_URL=... PROVIDER_MODE=mock JWT_SECRET=test \
 *      npx jest --runInBand --config test/jest-e2e.json
 */

const rand = Math.random().toString(36).slice(2, 10);
const donorCreds = {
  email: `donor-${rand}@kindora.test`,
  password: 'DonorPass123!',
  firstName: 'Tola',
  lastName: 'Ade',
};
const organizerCreds = {
  email: `organizer-${rand}@kindora.test`,
  password: 'Organizer123!',
  firstName: 'Ngozi',
  lastName: 'Bello',
};
const ADMIN_EMAIL = 'admin@kindora.com';
const ADMIN_PASSWORD = process.env.SEED_ADMIN_PASSWORD ?? 'Kindora-Admin-2026!';

// Two additional administrators for the dual-approval + executor-separation
// matrix (v1.0.7 §8.2). They start as normal users and are promoted to ADMIN
// directly in the database — there is no public role-escalation API by design.
const rand2 = Math.random().toString(36).slice(2, 10);
const admin2Creds = {
  email: `mp-admin2-${rand2}@kindora.test`,
  password: 'MpAdmin2Pass1!',
  firstName: 'Mfe',
  lastName: 'Second',
};
const admin3Creds = {
  email: `mp-admin3-${rand2}@kindora.test`,
  password: 'MpAdmin3Pass1!',
  firstName: 'Mfe',
  lastName: 'Third',
};
// The settlement EXECUTOR — a fourth distinct identity (v1.0.7 §8.2). Fresh
// per run so its MFA enrollment never collides with other suites that may
// also use the seed admin for non-MFA actions only.
const admin4Creds = {
  email: `mp-admin4-${rand2}@kindora.test`,
  password: 'MpAdmin4Pass1!',
  firstName: 'Mfe',
  lastName: 'Fourth',
};

const STORY =
  'This campaign exists to verify the KINDORA money path end to end. It posts every movement to the double-entry ' +
  'ledger, exercises webhook verification and idempotency, and demonstrates the public transparency features that ' +
  'KINDORA is built on. All amounts are tracked in minor units.';

maybeDescribe('Money path (e2e, mock provider)', () => {
  let app: NestExpressApplication;
  let donorToken = '';
  let organizerToken = '';
  let adminToken = '';
  let admin2Token = '';
  let admin3Token = '';
  let admin3Id = '';
  let admin4Token = '';
  let admin4Id = '';
  let campaignId = '';
  let campaignSlug = '';
  let donationPublicRef = '';
  let withdrawalId = '';

  /** Normalise express set-cookie (string | string[]) into a single header value. */
  function cookieOf(res: { headers: Record<string, unknown> }): string {
    const raw = res.headers['set-cookie'];
    if (!raw) return '';
    return Array.isArray(raw) ? raw.join('; ') : String(raw);
  }

  beforeAll(async () => {
    app = await createTestApp();

    // Approving administrators (fresh per run) for the dual-approval flow.
    await request(app.getHttpServer()).post('/api/v1/auth/register').send(admin2Creds).expect(201);
    await request(app.getHttpServer()).post('/api/v1/auth/register').send(admin3Creds).expect(201);
    await getTestPrisma().user.update({ where: { email: admin2Creds.email }, data: { role: 'ADMIN' } });
    await getTestPrisma().user.update({ where: { email: admin3Creds.email }, data: { role: 'ADMIN' } });

    const admin2Login = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: admin2Creds.email, password: admin2Creds.password })
      .expect([200, 201]);
    admin2Token = admin2Login.body.accessToken;

    const admin3Login = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: admin3Creds.email, password: admin3Creds.password })
      .expect([200, 201]);
    admin3Token = admin3Login.body.accessToken;
    admin3Id = (await getTestPrisma().user.findUnique({ where: { email: admin3Creds.email } }))!.id;

    await request(app.getHttpServer()).post('/api/v1/auth/register').send(admin4Creds).expect(201);
    await getTestPrisma().user.update({ where: { email: admin4Creds.email }, data: { role: 'ADMIN' } });
    const admin4Login = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: admin4Creds.email, password: admin4Creds.password })
      .expect([200, 201]);
    admin4Token = admin4Login.body.accessToken;
    admin4Id = (await getTestPrisma().user.findUnique({ where: { email: admin4Creds.email } }))!.id;
  });

  afterAll(async () => {
    await closeTestApp();
  });

  it('health endpoints respond (database up; redis reflects configuration, fail-closed when unset)', async () => {
    const health = await request(app.getHttpServer()).get('/api/v1/health').expect(200);
    expect(health.body).toMatchObject({ status: 'ok', service: 'kindora-api' });

    const database = await request(app.getHttpServer()).get('/api/v1/health/database').expect(200);
    expect(database.body).toMatchObject({ status: 'ok', component: 'database' });

    // Redis health mirrors the runtime configuration: with REDIS_URL set and a
    // reachable server the probe is 200/configured:true; when REDIS_URL is
    // unset (offline default) it reports 503/configured:false — fail closed.
    const redis = await request(app.getHttpServer()).get('/api/v1/health/redis');
    const redisConfigured = Boolean(process.env.REDIS_URL);
    if (redisConfigured) {
      expect(redis.status).toBe(200);
      expect(redis.body).toMatchObject({ component: 'redis', configured: true });
    } else {
      expect([200, 503]).toContain(redis.status);
      expect(redis.body).toMatchObject({ component: 'redis', configured: false });
    }
  });

  it('registers donor and organizer, completes mock verification, acquires tokens', async () => {
    await request(app.getHttpServer()).post('/api/v1/auth/register').send(donorCreds).expect(201);
    await request(app.getHttpServer()).post('/api/v1/auth/register').send(organizerCreds).expect(201);

    const donorLogin = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: donorCreds.email, password: donorCreds.password })
      .expect([200, 201]); // POST default status; the smoke script accepts either
    expect(donorLogin.body.accessToken).toBeTruthy();
    expect(donorLogin.headers['set-cookie']).toBeDefined(); // kindora_refresh cookie issued
    donorToken = donorLogin.body.accessToken;

    const organizerLogin = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: organizerCreds.email, password: organizerCreds.password })
      .expect([200, 201]);
    organizerToken = organizerLogin.body.accessToken;

    // Mock-mode test hook: complete email verification without the email round-trip.
    await request(app.getHttpServer())
      .post('/api/v1/auth/dev/complete-verification')
      .send({ email: organizerCreds.email })
      .expect(200)
      .expect({ verified: true });
  });

  it('creates and submits a campaign as the verified organizer', async () => {
    const created = await request(app.getHttpServer())
      .post('/api/v1/campaigns')
      .set('Authorization', `Bearer ${organizerToken}`)
      .send({
        title: `Integration Test Campaign ${rand}`,
        excerpt: 'End-to-end verification campaign.',
        story: STORY, // backend contract: story >= 200 chars
        categorySlug: 'education',
        country: 'Nigeria',
        targetAmountMajor: 1000000,
        currency: 'NGN',
      })
      .expect(201);

    expect(created.body.campaign).toMatchObject({ slug: expect.any(String) });
    campaignId = created.body.campaign.id;
    campaignSlug = created.body.campaign.slug;
    expect(campaignId).toBeTruthy();
    expect(campaignSlug).toBeTruthy();

    await request(app.getHttpServer())
      .post(`/api/v1/campaigns/${campaignId}/submit`)
      .set('Authorization', `Bearer ${organizerToken}`)
      .expect([200, 201]);
  });

  it('admin (seeded) approves the campaign; admin stats + reconciliation reachable', async () => {
    const adminLogin = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD })
      .expect([200, 201]);
    adminToken = adminLogin.body.accessToken;

    await request(app.getHttpServer())
      .post(`/api/v1/admin/campaigns/${campaignId}/approve`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ note: 'integration test' })
      .expect([200, 201]);

    await request(app.getHttpServer())
      .get('/api/v1/admin/stats')
      .set('Authorization', `Bearer ${adminToken}`)
      .expect(200);
    await request(app.getHttpServer())
      .get('/api/v1/admin/reconciliation')
      .set('Authorization', `Bearer ${adminToken}`)
      .expect(200);
  });

  it('donor donates 2,500,000 + 125,000 tip via the MOCK provider', async () => {
    const donation = await request(app.getHttpServer())
      .post('/api/v1/donations')
      .set('Authorization', `Bearer ${donorToken}`)
      .send({
        campaignSlug,
        amountMinor: 2500000,
        tipAmountMinor: 125000,
        provider: 'MOCK',
        message: 'Integration test donation',
      })
      .expect(201);

    expect(donation.body.donation).toMatchObject({
      publicRef: expect.any(String),
      amount: '2500000',
      status: 'PENDING',
    });
    // Mock adapter redirects back to the status page with a mock marker.
    expect(donation.body.redirectUrl).toContain('/donate/status?ref=');
    expect(donation.body.redirectUrl).toContain('mock=1');

    donationPublicRef = donation.body.donation.publicRef;
    expect(donationPublicRef).toBeTruthy();
  });

  it('server-side verify drives PENDING -> SUCCEEDED with a receipt number', async () => {
    // NOTE: the URL provider label must be one of the public provider names
    // (MOCK is not in the route allowlist) — the donation record itself
    // decides which adapter verifies (authoritative provider, never the URL).
    const status = await request(app.getHttpServer())
      .get(`/api/v1/donations/status/PAYSTACK/${donationPublicRef}`)
      .expect(200);

    expect(status.body.status).toBe('SUCCEEDED');
    expect(status.body.receiptNumber).toMatch(/^RCP-/);
    expect(status.body.amount).toBe('2500000');
  });

  it('duplicate verify + mock webhook replay do NOT double-post (balance stays 2,500,000)', async () => {
    // Second verification poll of the same donation (PAYSTACK is only the
    // URL label; the record's provider — MOCK — is authoritative).
    const status = await request(app.getHttpServer())
      .get(`/api/v1/donations/status/PAYSTACK/${donationPublicRef}`)
      .expect(200);
    expect(status.body.status).toBe('SUCCEEDED');

    // Signed paystack webhook replay for the same donation must be a no-op:
    // the donation is already SUCCEEDED, so the handler acknowledges the
    // delivery (ALREADY_RESOLVED) without touching money state. The payload
    // carries the real HMAC-SHA512 signature; an unsigned body would be
    // rejected 400 by the signature check instead of being absorbed.
    const signed = signedPaystack({ event: 'charge.success', data: { reference: donationPublicRef } });
    await request(app.getHttpServer())
      .post('/api/v1/payments/paystack/webhook')
      .set(signed.headers)
      .send(signed.body)
      .expect(201)
      .expect({ received: true });

    // The ledger balance for the campaign must be exactly one donation.
    const ledger = await request(app.getHttpServer()).get(`/api/v1/impact/campaigns/${campaignSlug}`).expect(200);
    expect(ledger.body.balanceMinor).toBe('2500000');
    expect(ledger.body.campaign.raisedAmount).toBe('2500000');
  });

  it('campaign denormalised counter is ledger-consistent (raisedAmount 2,500,000)', async () => {
    const campaign = await request(app.getHttpServer()).get(`/api/v1/campaigns/${campaignSlug}`).expect(200);
    expect(campaign.body.raisedAmount).toBe('2500000');
    expect(campaign.body.donorCount).toBe(1);
  });

  // ---- v1.0.4 helpers -------------------------------------------------------

  function totpCode(secretBase32: string, stepOffset = 0): string {
    const buf = base32Decode(secretBase32.replace(/=+$/, ''));
    const counter = BigInt(Math.floor(Date.now() / 1000 / TOTP_STEP_SECONDS)) + BigInt(stepOffset);
    return hotp(buf, counter);
  }

  // v1.0.9 — the two-step manual settlement issues TWO purpose-bound MFA
  // challenges for the same executor, so the enrollment secret is cached per
  // bearer and a second call exchanges against the already-active enrollment.
  const enrolledSecrets = new Map<string, string>();

  /** REAL fresh-MFA flow against real Redis; returns the single-use challenge token. */
  async function freshMfa(bearer: string, purpose: string, scope: string): Promise<string> {
    const status = await request(app.getHttpServer())
      .get('/api/v1/mfa/status')
      .set('Authorization', `Bearer ${bearer}`)
      .expect(200);
    const cached = enrolledSecrets.get(bearer);
    if (status.body.active) {
      if (!cached) {
        throw new Error('Admin already MFA-active in the persistent test DB — use fresh admin accounts for MFA');
      }
      return exchangeChallenge(bearer, purpose, scope, cached);
    }
    const enroll = await request(app.getHttpServer())
      .post('/api/v1/mfa/enroll')
      .set('Authorization', `Bearer ${bearer}`)
      .expect([200, 201]);
    const secret = enroll.body.secret as string;
    enrolledSecrets.set(bearer, secret);
    await request(app.getHttpServer())
      .post('/api/v1/mfa/confirm')
      .set('Authorization', `Bearer ${bearer}`)
      .send({ code: totpCode(secret) })
      .expect([200, 201]);
    return exchangeChallenge(bearer, purpose, scope, secret);
  }

  /** Step-boundary safe challenge exchange (+1 / +2 offsets across 30s windows). */
  async function exchangeChallenge(bearer: string, purpose: string, scope: string, secret: string): Promise<string> {
    for (const offset of [0, 1, 2]) {
      const attempt = await request(app.getHttpServer())
        .post('/api/v1/mfa/challenge')
        .set('Authorization', `Bearer ${bearer}`)
        .send({ purpose, scope, code: totpCode(secret, offset) });
      if (attempt.status === 200 || attempt.status === 201) {
        return attempt.body.challengeToken as string;
      }
      const msg = String(attempt.body?.message ?? '');
      if (!/already been used|Invalid or expired/.test(msg)) {
        throw new Error(`MFA challenge rejected unexpectedly (${attempt.status}): ${msg}`);
      }
    }
    throw new Error('No usable TOTP offset for MFA challenge — clock step boundary race persisted');
  }

  async function makeEvidenceFile(uploaderId: string) {
    return getTestPrisma().storedFile.create({
      data: {
        key: `evidence/money-path-${rand}-${Math.random().toString(36).slice(2, 8)}.pdf`,
        kind: 'PAYOUT_EVIDENCE',
        visibility: 'PRIVATE',
        status: 'APPROVED',
        scanVerdict: 'CLEAN',
        fileName: 'bank-transfer-receipt.pdf',
        contentType: 'application/pdf',
        sizeBytes: 2048n,
        uploaderId,
      },
    });
  }

  it('withdrawal flow: request 1,000,000 -> dual approval (3 distinct admins, fresh MFA) -> settle -> available 1,500,000', async () => {
    // Organizer sees the full ledger balance available for payout.
    const available = await request(app.getHttpServer())
      .get(`/api/v1/withdrawals/available/${campaignId}`)
      .set('Authorization', `Bearer ${organizerToken}`)
      .expect(200);
    expect(available.body.availableMinor).toBe('2500000');

    const withdrawal = await request(app.getHttpServer())
      .post('/api/v1/withdrawals')
      .set('Authorization', `Bearer ${organizerToken}`)
      .send({
        campaignId,
        amountMinor: 1000000,
        method: 'BANK',
        destination: { accountName: 'Ngozi Bello', accountNumber: '0123456789', bankName: 'Test Bank' },
      })
      .expect(201);
    withdrawalId = withdrawal.body.id;
    expect(withdrawal.body.status).toBe('PENDING');

    // v1.0.4: TWO distinct approvers + a THIRD distinct executor, each with a
    // fresh single-use MFA challenge, and a registered private evidence file.
    const firstToken = await freshMfa(admin2Token, 'PAYOUT_FIRST_APPROVAL', withdrawalId);
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/approve`)
      .set('Authorization', `Bearer ${admin2Token}`)
      .set('x-mfa-challenge', firstToken)
      .expect([200, 201]);

    const secondToken = await freshMfa(admin3Token, 'PAYOUT_SECOND_APPROVAL', withdrawalId);
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/second-approval`)
      .set('Authorization', `Bearer ${admin3Token}`)
      .set('x-mfa-challenge', secondToken)
      .send({ note: 'second approval (integration)' })
      .expect([200, 201]);

    // v1.0.7 §8.2 — a FOURTH distinct executor: admin4 settles with a fresh
    // single-use MFA challenge and their own registered private evidence file
    // (the first approver may no longer execute the payout; the seed admin
    // stays a non-MFA identity so suites never fight over its enrollment).
    // v1.0.9 §5.1 — TWO-STEP manual settlement: the executor FIRST authorizes
    // the manual payout intent (binding the immutable manual approval snapshot
    // on both approvals), THEN settles with the registered evidence file.
    const intentToken = await freshMfa(admin4Token, 'PAYOUT_EXECUTION', withdrawalId);
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/execute`)
      .set('Authorization', `Bearer ${admin4Token}`)
      .set('x-mfa-challenge', intentToken)
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', note: 'offline settlement authorized (integration)' })
      .expect([200, 201]);

    const evidence = await makeEvidenceFile(admin4Id);
    const settleToken = await freshMfa(admin4Token, 'PAYOUT_SETTLEMENT', withdrawalId);
    await request(app.getHttpServer())
      .post(`/api/v1/withdrawals/${withdrawalId}/settle`)
      .set('Authorization', `Bearer ${admin4Token}`)
      .set('x-mfa-challenge', settleToken)
      // v1.0.4: settlement REQUIRES the payout channel + provider reference +
      // a registered private evidence file (arbitrary URLs are rejected).
      .send({ payoutProvider: 'MANUAL_BANK_TRANSFER', providerTransferRef: `it-${rand}`, evidenceFileId: evidence.id })
      .expect([200, 201]);

    // Available drops by the paid amount only after the payout is POSTED.
    const after = await request(app.getHttpServer())
      .get(`/api/v1/withdrawals/available/${campaignId}`)
      .set('Authorization', `Bearer ${organizerToken}`)
      .expect(200);
    expect(after.body.availableMinor).toBe('1500000');
  });

  it('public transparency feed shows the ledger transactions (total >= 2)', async () => {
    const feed = await request(app.getHttpServer()).get('/api/v1/impact/transactions?page=1').expect(200);
    expect(feed.body.total).toBeGreaterThanOrEqual(2);
    const types = feed.body.items.map((t: { type: string }) => t.type);
    expect(types).toContain('DONATION');
    expect(types).toContain('WITHDRAWAL');
    for (const item of feed.body.items) {
      for (const entry of item.entries) {
        expect(typeof entry.amount).toBe('string'); // BigInt serialized
      }
    }
  });

  it('donor can list own donations and notifications', async () => {
    const mine = await request(app.getHttpServer())
      .get('/api/v1/donations/mine')
      .set('Authorization', `Bearer ${donorToken}`)
      .expect(200);
    expect(mine.body.total).toBeGreaterThanOrEqual(1);
    expect(mine.body.items.some((d: { publicRef: string }) => d.publicRef === donationPublicRef)).toBe(true);

    await request(app.getHttpServer())
      .get('/api/v1/users/me/notifications')
      .set('Authorization', `Bearer ${donorToken}`)
      .expect(200);
  });

  it('impact summary is reachable and reports successful donations', async () => {
    const summary = await request(app.getHttpServer()).get('/api/v1/impact/summary').expect(200);
    expect(summary.body.totalDonations).toBeGreaterThanOrEqual(1);
    expect(summary.body.ledger).toHaveProperty('ledgerTransactions');
  });
});
