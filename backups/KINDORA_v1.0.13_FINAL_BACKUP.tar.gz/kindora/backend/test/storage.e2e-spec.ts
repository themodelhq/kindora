import request from 'supertest';
import type { NestExpressApplication } from '@nestjs/platform-express';
import { closeTestApp, createTestApp, getTestPrisma, maybeDescribe } from './setup';

/**
 * Storage document-authorization integration tests (§11).
 *
 * Two-layer behaviour is covered:
 *  1. WITHOUT configured object storage every storage endpoint answers 503
 *     (explicit configuration error, never a silent open endpoint).
 *  2. With storage configured, the PRIVATE-document GET enforces the full
 *     authorization matrix. StoredFile rows are registered directly through
 *     the test app's Prisma client (uploads need a real object store, the
 *     authorization logic does not — presigned GET URLs are computed locally):
 *      - non-owner authenticated user -> 403 (known file, no entitlement);
 *      - unknown/untracked key -> 404 (fail closed: a leaked key grants nothing);
 *      - admin -> 200 AND an immutable PRIVILEGED_DOCUMENT_ACCESS audit row;
 *      - owner -> 200 (owner access is NOT audited as privileged);
 *      - sensitive kinds (DOCUMENT) with scanVerdict != CLEAN are blocked for
 *        non-admins even for the owner (fail-safe quarantine), while admins
 *        can still review them (audited).
 */

const rand = Math.random().toString(36).slice(2, 10);
const userACreds = {
  email: `st-user-a-${rand}@kindora.test`,
  password: 'StorageAPass1!',
  firstName: 'Amara',
  lastName: 'Owner',
};
const userBCreds = {
  email: `st-user-b-${rand}@kindora.test`,
  password: 'StorageBPass1!',
  firstName: 'Bola',
  lastName: 'Other',
};
const ADMIN_EMAIL = 'admin@kindora.com';
const ADMIN_PASSWORD = process.env.SEED_ADMIN_PASSWORD ?? 'Kindora-Admin-2026!';

maybeDescribe('Storage documents (e2e, authorization + audit)', () => {
  let app: NestExpressApplication;
  let tokenA = '';
  let tokenB = '';
  let adminToken = '';
  let userAId = '';
  let adminId = '';
  let cleanFileId = '';
  let quarantinedFileId = '';

  const cleanKey = () => `document/${userAId}/contract-${rand}.pdf`;
  const pendingKey = () => `document/${userAId}/pending-${rand}.pdf`;

  beforeAll(async () => {
    // Guarantee the "storage not configured" precondition even when another
    // spec file in the same worker left STORAGE_* behind.
    delete process.env.STORAGE_ENDPOINT;
    delete process.env.STORAGE_BUCKET;
    delete process.env.STORAGE_ACCESS_KEY;
    delete process.env.STORAGE_SECRET_KEY;

    app = await createTestApp();

    await request(app.getHttpServer()).post('/api/v1/auth/register').send(userACreds).expect(201);
    await request(app.getHttpServer()).post('/api/v1/auth/register').send(userBCreds).expect(201);

    const a = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: userACreds.email, password: userACreds.password })
      .expect([200, 201]);
    tokenA = a.body.accessToken;

    const b = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: userBCreds.email, password: userBCreds.password })
      .expect([200, 201]);
    tokenB = b.body.accessToken;

    const admin = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD })
      .expect([200, 201]);
    adminToken = admin.body.accessToken;

    const prisma = getTestPrisma();
    const userA = await prisma.user.findUnique({ where: { email: userACreds.email }, select: { id: true } });
    const adminUser = await prisma.user.findUnique({ where: { email: ADMIN_EMAIL }, select: { id: true } });
    userAId = userA!.id;
    adminId = adminUser!.id;
  });

  afterAll(async () => {
    // Storage env is process-global: clean up so later spec files in the same
    // worker (jest --runInBand) keep the "not configured" default.
    delete process.env.STORAGE_ENDPOINT;
    delete process.env.STORAGE_BUCKET;
    delete process.env.STORAGE_ACCESS_KEY;
    delete process.env.STORAGE_SECRET_KEY;
    await closeTestApp();
  });

  it('returns 503 for document access while object storage is not configured', async () => {
    const res = await request(app.getHttpServer())
      .get(`/api/v1/storage/documents/document/${userAId}/whatever.pdf`)
      .set('Authorization', `Bearer ${tokenB}`)
      .expect(503);
    expect(res.body.message).toContain('not configured');
  });

  it('enforces the authorization matrix for private documents once storage is configured', async () => {
    // Configure storage from here on (config() reads process.env per call;
    // presigned URLs are computed locally, no object store is contacted).
    process.env.STORAGE_ENDPOINT = 'http://localhost:9000';
    process.env.STORAGE_BUCKET = 'kindora-integration-test';
    process.env.STORAGE_ACCESS_KEY = 'integration-test-access-key';
    process.env.STORAGE_SECRET_KEY = 'integration-test-secret-key';

    // Register files directly in the StoredFile registry (ownership + scan state).
    const prisma = getTestPrisma();
    const cleanFile = await prisma.storedFile.create({
      data: {
        key: cleanKey(),
        kind: 'DOCUMENT',
        visibility: 'PRIVATE',
        status: 'APPROVED',
        scanVerdict: 'CLEAN',
        fileName: `contract-${rand}.pdf`,
        contentType: 'application/pdf',
        sizeBytes: 1024n,
        uploaderId: userAId,
      },
    });
    cleanFileId = cleanFile.id;
    const quarantined = await prisma.storedFile.create({
      data: {
        key: pendingKey(),
        kind: 'DOCUMENT',
        visibility: 'PRIVATE',
        status: 'QUARANTINED',
        scanVerdict: 'UNAVAILABLE',
        fileName: `pending-${rand}.pdf`,
        contentType: 'application/pdf',
        sizeBytes: 1024n,
        uploaderId: userAId,
      },
    });
    quarantinedFileId = quarantined.id;

    // 1. Known file, non-owner authenticated user -> 403 (no entitlement leak).
    const forbidden = await request(app.getHttpServer())
      .get(`/api/v1/storage/documents/${cleanKey()}`)
      .set('Authorization', `Bearer ${tokenB}`)
      .expect(403);
    expect(forbidden.body.message).toContain('do not have access');

    // 2. Unknown (untracked) key -> 404 even though the caller is an admin:
    //    fail closed, a guessed/leaked storage key alone grants nothing.
    const missing = await request(app.getHttpServer())
      .get(`/api/v1/storage/documents/document/nobody/unknown-${rand}.pdf`)
      .set('Authorization', `Bearer ${adminToken}`)
      .expect(404);
    expect(missing.body.message).toContain('not found');

    // 3. Admin access to a known file -> 200 + PRIVILEGED_DOCUMENT_ACCESS audit row.
    const adminView = await request(app.getHttpServer())
      .get(`/api/v1/storage/documents/${cleanKey()}`)
      .set('Authorization', `Bearer ${adminToken}`)
      .expect(200);
    expect(adminView.body.fileId).toBe(cleanFileId);
    expect(adminView.body.scanVerdict).toBe('CLEAN');
    expect(typeof adminView.body.url).toBe('string');
    expect(adminView.body.url.length).toBeGreaterThan(0);

    const adminAudit = await prisma.auditLog.findFirst({
      where: { action: 'PRIVILEGED_DOCUMENT_ACCESS', entityId: cleanFileId, actorUserId: adminId },
    });
    expect(adminAudit).not.toBeNull();

    // 4. Owner access to their own CLEAN document -> 200, and owner access is
    //    NOT logged as privileged (only non-owners are audited).
    const ownerAuditsBefore = await prisma.auditLog.count({ where: { entityId: cleanFileId } });
    const ownerView = await request(app.getHttpServer())
      .get(`/api/v1/storage/documents/${cleanKey()}`)
      .set('Authorization', `Bearer ${tokenA}`)
      .expect(200);
    expect(ownerView.body.fileId).toBe(cleanFileId);
    const ownerAuditsAfter = await prisma.auditLog.count({ where: { entityId: cleanFileId } });
    expect(ownerAuditsAfter).toBe(ownerAuditsBefore);

    // 5. Sensitive kind with scanVerdict UNAVAILABLE: blocked even for the
    //    OWNER (fail-safe quarantine for non-admins).
    const blockedOwner = await request(app.getHttpServer())
      .get(`/api/v1/storage/documents/${pendingKey()}`)
      .set('Authorization', `Bearer ${tokenA}`)
      .expect(403);
    expect(blockedOwner.body.message).toContain('pending security review');

    // 6. Admins may review quarantined sensitive documents; the access is audited.
    const adminReview = await request(app.getHttpServer())
      .get(`/api/v1/storage/documents/${pendingKey()}`)
      .set('Authorization', `Bearer ${adminToken}`)
      .expect(200);
    expect(adminReview.body.scanVerdict).toBe('UNAVAILABLE');
    const reviewAudit = await prisma.auditLog.findFirst({
      where: { action: 'PRIVILEGED_DOCUMENT_ACCESS', entityId: quarantinedFileId, actorUserId: adminId },
    });
    expect(reviewAudit).not.toBeNull();
  });

  it('requires authentication for private document access (401 without a token)', async () => {
    await request(app.getHttpServer()).get(`/api/v1/storage/documents/${cleanKey()}`).expect(401);
  });
});
