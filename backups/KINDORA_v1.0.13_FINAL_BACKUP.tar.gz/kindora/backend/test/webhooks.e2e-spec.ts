import { createHash, createHmac } from 'node:crypto';
import request from 'supertest';
import type { NestExpressApplication } from '@nestjs/platform-express';
import { closeTestApp, createTestApp, getTestPrisma, maybeDescribe } from './setup';

/**
 * Webhook security integration tests (hardening spec §11 — PAYSTACK provider).
 *
 * IMPORTANT — how the provider boundary is handled: in PROVIDER_MODE=mock the
 * paystack webhook endpoint still uses the REAL PaystackService (adapterFor
 * only substitutes the MOCK provider, never PAYSTACK). This suite therefore
 * exercises the production signature scheme instead of a fake one:
 *  1. PAYSTACK_SECRET_KEY is set BEFORE the app boots and every valid
 *     delivery is signed with the real HMAC-SHA512(raw body) scheme —
 *     signature verification is real, not mocked;
 *  2. global fetch is stubbed ONLY for api.paystack.co hosts so the
 *     authoritative re-verification step (the webhook must re-check the
 *     transaction against the provider API before applying it) succeeds
 *     deterministically. Every other URL falls through to the real fetch.
 *
 * Covered invariants:
 *  - unknown event types are acknowledged (2xx) but NEVER change donation or
 *    ledger state (default-deny allowlist);
 *  - a successful charge is applied EXACTLY once: a duplicate delivery is
 *    absorbed via the (provider,eventId) uniqueness and no second ledger
 *    posting occurs (reference `donation:<id>` stays count 1);
 *  - refund.processed flips the donation to REFUNDED, posts compensating
 *    double-entry rows (type REFUND, reference `refund:<refundId>`) and
 *    restores the campaign raisedAmount;
 *  - an invalid signature is rejected with 400, recorded with
 *    signatureValid=false, and no signatureValid=true row is created.
 */

// Set BEFORE createTestApp(): the ConfigService factory reads process.env.
process.env.PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY ?? 'sk_test_kindora_webhook_suite';

const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET_KEY;

const rand = Math.random().toString(36).slice(2, 10);
const donorCreds = {
  email: `wh-donor-${rand}@kindora.test`,
  password: 'WhDonorPass1!',
  firstName: 'Wale',
  lastName: 'Donor',
};
const organizerCreds = {
  email: `wh-organizer-${rand}@kindora.test`,
  password: 'WhOrganizer1!',
  firstName: 'Ngo',
  lastName: 'Organizer',
};
const ADMIN_EMAIL = 'admin@kindora.com';
const ADMIN_PASSWORD = process.env.SEED_ADMIN_PASSWORD ?? 'Kindora-Admin-2026!';

const STORY =
  'This campaign backs the webhook security integration suite. Every delivery below is signed with the real ' +
  'Paystack HMAC scheme, re-verified against the stubbed provider API, and every financial movement it triggers ' +
  'must be visible as an exactly-once posting in the double-entry ledger.';

/** Signs a payload exactly the way Paystack does: HMAC-SHA512 of the raw body. */
function signedPaystack(payload: Record<string, unknown>): { body: string; headers: Record<string, string> } {
  const body = JSON.stringify(payload);
  return {
    body,
    headers: {
      'Content-Type': 'application/json',
      'x-paystack-signature': createHmac('sha512', PAYSTACK_SECRET).update(body).digest('hex'),
    },
  };
}

// ---- api.paystack.co boundary stub (initialize + verify only) ---------------
const realFetch = globalThis.fetch;
const initializeAmounts = new Map<string, number>();
const initializeCurrencies = new Map<string, string>();

function jsonResponse(body: unknown): Response {
  return new Response(JSON.stringify(body), { status: 200, headers: { 'content-type': 'application/json' } });
}

async function paystackAwareFetch(input: Parameters<typeof fetch>[0], init?: Parameters<typeof fetch>[1]): Promise<Response> {
  const url = typeof input === 'string' || input instanceof URL ? String(input) : input.url;
  if (!url.includes('api.paystack.co')) return realFetch(input as Parameters<typeof fetch>[0], init);
  if (url.includes('/transaction/initialize')) {
    const payload = JSON.parse(String(init?.body ?? '{}')) as { reference: string; amount: number; currency: string };
    initializeAmounts.set(payload.reference, payload.amount);
    initializeCurrencies.set(payload.reference, payload.currency);
    return jsonResponse({
      status: true,
      message: 'Authorization URL created',
      data: { authorization_url: 'https://checkout.paystack.test/authorize', reference: payload.reference },
    });
  }
  if (url.includes('/transaction/verify/')) {
    const reference = decodeURIComponent(url.slice(url.indexOf('/transaction/verify/') + '/transaction/verify/'.length));
    return jsonResponse({
      status: true,
      message: 'Verification successful',
      data: {
        status: 'success',
        reference,
        amount: initializeAmounts.get(reference) ?? 0,
        currency: initializeCurrencies.get(reference) ?? 'NGN',
        fees: 0,
        authorization: { authorization_token: 'AUTH_kindora_test' },
      },
    });
  }
  return jsonResponse({ status: false, message: 'unmocked paystack endpoint' });
}

maybeDescribe('Payment webhooks (e2e, PAYSTACK signature scheme)', () => {
  let app: NestExpressApplication;
  let donorToken = '';
  let adminToken = '';
  let campaignId = '';
  let campaignSlug = '';

  /** Creates a PENDING PAYSTACK donation through the public API. */
  async function createPaystackDonation(amountMinor: number, tipMinor: number): Promise<string> {
    const res = await request(app.getHttpServer())
      .post('/api/v1/donations')
      .set('Authorization', `Bearer ${donorToken}`)
      .send({ campaignSlug, amountMinor, tipAmountMinor: tipMinor, provider: 'PAYSTACK' })
      .expect(201);
    expect(res.body.donation.status).toBe('PENDING');
    expect(res.body.redirectUrl).toContain('checkout.paystack.test'); // stubbed initialize
    return res.body.donation.publicRef as string;
  }

  async function donationId(publicRef: string): Promise<string> {
    const donation = await getTestPrisma().donation.findUnique({ where: { publicRef }, select: { id: true } });
    expect(donation).not.toBeNull();
    return donation!.id;
  }

  async function donationStatus(publicRef: string): Promise<string> {
    const res = await request(app.getHttpServer()).get(`/api/v1/donations/${publicRef}`).expect(200);
    return res.body.status as string;
  }

  async function campaignRaised(): Promise<string> {
    const res = await request(app.getHttpServer()).get(`/api/v1/campaigns/${campaignSlug}`).expect(200);
    return res.body.raisedAmount as string;
  }

  async function postWebhook(payload: Record<string, unknown>, signed = true) {
    if (signed) {
      const { body, headers } = signedPaystack(payload);
      return request(app.getHttpServer()).post('/api/v1/payments/paystack/webhook').set(headers).send(body);
    }
    return request(app.getHttpServer()).post('/api/v1/payments/paystack/webhook').send(payload);
  }

  beforeAll(async () => {
    globalThis.fetch = paystackAwareFetch as typeof fetch;
    app = await createTestApp();

    // Users: donor + verified organizer + seeded admin.
    await request(app.getHttpServer()).post('/api/v1/auth/register').send(donorCreds).expect(201);
    await request(app.getHttpServer()).post('/api/v1/auth/register').send(organizerCreds).expect(201);
    await request(app.getHttpServer())
      .post('/api/v1/auth/dev/complete-verification')
      .send({ email: organizerCreds.email })
      .expect(200)
      .expect({ verified: true });

    const donorLogin = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: donorCreds.email, password: donorCreds.password })
      .expect([200, 201]);
    donorToken = donorLogin.body.accessToken;

    const adminLogin = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD })
      .expect([200, 201]);
    adminToken = adminLogin.body.accessToken;

    const organizerLogin = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: organizerCreds.email, password: organizerCreds.password })
      .expect([200, 201]);

    const created = await request(app.getHttpServer())
      .post('/api/v1/campaigns')
      .set('Authorization', `Bearer ${organizerLogin.body.accessToken}`)
      .send({
        title: `Webhook Security Campaign ${rand}`,
        excerpt: 'Webhook security suite.',
        story: STORY,
        categorySlug: 'education',
        country: 'Nigeria',
        targetAmountMajor: 500000,
        currency: 'NGN',
      })
      .expect(201);
    campaignId = created.body.campaign.id;
    campaignSlug = created.body.campaign.slug;

    await request(app.getHttpServer())
      .post(`/api/v1/campaigns/${campaignId}/submit`)
      .set('Authorization', `Bearer ${organizerLogin.body.accessToken}`)
      .expect([200, 201]);
    await request(app.getHttpServer())
      .post(`/api/v1/admin/campaigns/${campaignId}/approve`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ note: 'webhook suite' })
      .expect([200, 201]);
  });

  afterAll(async () => {
    globalThis.fetch = realFetch;
    await closeTestApp();
  });

  it('acknowledges an unknown event type (payout.settled) without touching donation or ledger state', async () => {
    const publicRef = await createPaystackDonation(250000, 0);
    const id = await donationId(publicRef);
    const raisedBefore = await campaignRaised();

    const { body, headers } = signedPaystack({ event: 'payout.settled', data: { reference: publicRef } });
    const res = await request(app.getHttpServer())
      .post('/api/v1/payments/paystack/webhook')
      .set(headers)
      .send(body)
      .expect([200, 201]); // Nest POST default is 201; providers only need a 2xx ack
    expect(res.body).toEqual({ received: true });

    // Default-deny: donation state and ledger are untouched.
    expect(await donationStatus(publicRef)).toBe('PENDING');
    expect(await getTestPrisma().ledgerTransaction.count({ where: { reference: `donation:${id}` } })).toBe(0);
    expect(await campaignRaised()).toBe(raisedBefore);

    // The delivery is still recorded (audit) with a valid signature.
    const recorded = await getTestPrisma().webhookEvent.findFirst({
      where: { provider: 'PAYSTACK', eventType: 'payout.settled', signatureValid: true },
    });
    expect(recorded).not.toBeNull();
  });

  it('rejects an invalid signature with 400 and never records a signatureValid=true delivery', async () => {
    const publicRef = await createPaystackDonation(150000, 0);
    const validBefore = await getTestPrisma().webhookEvent.count({ where: { provider: 'PAYSTACK', signatureValid: true } });

    // Correctly-formed payload, but NO signature header -> verifier fails.
    const res = await request(app.getHttpServer())
      .post('/api/v1/payments/paystack/webhook')
      .send({ event: 'charge.success', data: { reference: publicRef } })
      .expect(400);
    expect(JSON.stringify(res.body)).toContain('signature');

    const invalidRow = await getTestPrisma().webhookEvent.findFirst({
      where: { provider: 'PAYSTACK', signatureValid: false, error: 'signature verification failed' },
      orderBy: { createdAt: 'desc' },
    });
    expect(invalidRow).not.toBeNull();

    // No signatureValid=true row appeared, and the donation was not completed.
    const validAfter = await getTestPrisma().webhookEvent.count({ where: { provider: 'PAYSTACK', signatureValid: true } });
    expect(validAfter).toBe(validBefore);
    expect(await donationStatus(publicRef)).toBe('PENDING');
  });

  it('applies charge.success exactly once: duplicate deliveries are absorbed and the ledger posts once', async () => {
    const publicRef = await createPaystackDonation(400000, 12500);
    const id = await donationId(publicRef);
    const raisedBefore = await campaignRaised();

    const { body, headers } = signedPaystack({ event: 'charge.success', data: { reference: publicRef } });

    // First delivery: the payload alone is only a TRIGGER — the handler
    // re-verifies against the provider API (stubbed) before applying.
    const first = await request(app.getHttpServer())
      .post('/api/v1/payments/paystack/webhook')
      .set(headers)
      .send(body)
      .expect([200, 201]);
    expect(first.body).toEqual({ received: true });
    expect(await donationStatus(publicRef)).toBe('SUCCEEDED');

    // Exactly one ledger posting for the donation.
    const donationTxns = await getTestPrisma().ledgerTransaction.findMany({ where: { reference: `donation:${id}` } });
    expect(donationTxns).toHaveLength(1);
    expect(donationTxns[0].type).toBe('DONATION');

    // Second delivery of the IDENTICAL body: (provider,eventId) uniqueness
    // absorbs it as a duplicate — no second posting, no money movement.
    const second = await request(app.getHttpServer())
      .post('/api/v1/payments/paystack/webhook')
      .set(headers)
      .send(body)
      .expect([200, 201]);
    expect(second.body).toEqual({ received: true, duplicate: true });

    expect(await getTestPrisma().ledgerTransaction.count({ where: { reference: `donation:${id}` } })).toBe(1);
    expect(await donationStatus(publicRef)).toBe('SUCCEEDED');

    // raisedAmount moved exactly once (amount face value, tip excluded).
    expect(BigInt(await campaignRaised())).toBe(BigInt(raisedBefore) + 400000n);

    // Dedupe is recorded as a single WebhookEvent row (sha256-of-body eventId).
    const eventId = createHash('sha256').update(body).digest('hex');
    const eventRows = await getTestPrisma().webhookEvent.count({
      where: { provider: 'PAYSTACK', eventId, eventType: 'charge.success' },
    });
    expect(eventRows).toBe(1);
  });

  it('applies refund.processed: donation becomes REFUNDED, compensating ledger entries exist, raisedAmount decreases', async () => {
    const publicRef = await createPaystackDonation(250000, 0);
    const id = await donationId(publicRef);

    // Complete the donation first (refunds only apply to succeeded money).
    const success = signedPaystack({ event: 'charge.success', data: { reference: publicRef } });
    await request(app.getHttpServer())
      .post('/api/v1/payments/paystack/webhook')
      .set(success.headers)
      .send(success.body)
      .expect([200, 201]);
    expect(await donationStatus(publicRef)).toBe('SUCCEEDED');

    const raisedAtSuccess = await campaignRaised();
    expect(BigInt(raisedAtSuccess)).toBeGreaterThanOrEqual(250000n);

    const { body, headers } = signedPaystack({ event: 'refund.processed', data: { reference: publicRef } });
    const res = await request(app.getHttpServer())
      .post('/api/v1/payments/paystack/webhook')
      .set(headers)
      .send(body)
      .expect([200, 201]);
    expect(res.body).toEqual({ received: true });

    expect(await donationStatus(publicRef)).toBe('REFUNDED');

    // Compensating double-entry posting: type REFUND, reference refund:<refundId>.
    const refund = await getTestPrisma().refund.findFirst({ where: { donationId: id } });
    expect(refund).not.toBeNull();
    const refundTxn = await getTestPrisma().ledgerTransaction.findUnique({
      where: { reference: `refund:${refund!.id}` },
      include: { entries: true },
    });
    expect(refundTxn).not.toBeNull();
    expect(refundTxn!.type).toBe('REFUND');
    expect(refundTxn!.entries.length).toBeGreaterThanOrEqual(2); // campaign payable debit + clearing credit

    // Campaign liability restored: raisedAmount back to the pre-donation value.
    expect(BigInt(await campaignRaised())).toBe(BigInt(raisedAtSuccess) - 250000n);
  });
});
