#!/usr/bin/env bash
# KINDORA v1.0.7 — full backend integration suite (real PostgreSQL + real Redis)
set -uo pipefail
PGBIN=/tmp/pgtest/node_modules/@embedded-postgres/linux-x64/native/bin
DATA=/tmp/kindora-pgdata
REDIS=/tmp/redis-7.2.5/src/redis-server
export PATH="$PGBIN:$PATH"

pkill -9 postgres 2>/dev/null; pkill -f "redis-server 127" 2>/dev/null; sleep 1
rm -rf "$DATA" /tmp/kindora-pgsock && mkdir -p /tmp/kindora-pgsock
"$PGBIN/initdb" -D "$DATA" -U kindora --auth=trust -E UTF8 > /dev/null 2>&1 || { echo "initdb failed"; exit 1; }
"$PGBIN/pg_ctl" -D "$DATA" -l /tmp/kindora-pg4.log -o "-p 5433 -k /tmp/kindora-pgsock -c fsync=off" start -w > /dev/null 2>&1 || { echo "pg_ctl failed"; exit 1; }
"$REDIS" --port 5434 --bind 127.0.0.1 --save '' --appendonly no --daemonize yes > /dev/null 2>&1 || { echo "redis failed"; exit 1; }
sleep 1
node -e "
const {Client}=require('/tmp/pgtest/node_modules/pg');const Redis=require('/home/z/my-project/kindora/backend/node_modules/ioredis');
(async()=>{
  const c=new Client({host:'/tmp/kindora-pgsock',port:5433,user:'kindora',database:'postgres'});
  await c.connect();
  try{await c.query('DROP DATABASE IF EXISTS kindora_e2e WITH (FORCE);');}catch(e){console.error('drop:',e.message);}
  await c.query('CREATE DATABASE kindora_e2e;'); await c.end();
  const r=new Redis('redis://127.0.0.1:5434'); await r.ping(); r.disconnect();
  console.log('kindora_e2e + redis ready');
})().catch(e=>{console.error(e.message);process.exit(1)});
" || exit 1

export DATABASE_URL="postgresql://kindora@localhost:5433/kindora_e2e"
export REDIS_URL="redis://127.0.0.1:5434"
cd /home/z/my-project/kindora/backend

echo "== prisma migrate deploy (0001..0004) =="
npx prisma migrate deploy > /tmp/e2e-migrate.log 2>&1 && echo "migrate OK" || { tail -20 /tmp/e2e-migrate.log; exit 1; }

echo "== seed =="
SEED_ADMIN_PASSWORD='Kindora-Admin-2026!' DATABASE_URL="$DATABASE_URL" npx prisma db seed > /tmp/e2e-seed.log 2>&1 && echo "seed OK" || { tail -10 /tmp/e2e-seed.log; exit 1; }

echo ""
echo "== integration suite =="
RUN_INTEGRATION=1 DATABASE_URL="$DATABASE_URL" REDIS_URL="$REDIS_URL" PROVIDER_MODE=mock \
  JWT_SECRET=kindora-integration-test-secret \
  npx jest --config test/jest-e2e.json --runInBand 2>&1 | tail -25
E2E_EXIT=${PIPESTATUS[0]}

redis-cli -p 5434 shutdown nosave > /dev/null 2>&1
"$PGBIN/pg_ctl" -D "$DATA" stop -m fast > /dev/null 2>&1
echo "E2E_EXIT=$E2E_EXIT"
exit $E2E_EXIT
