#!/usr/bin/env bash
# Definitive structural check: migrations 0001..0004 must produce EXACTLY prisma/schema.prisma
set -uo pipefail
PGBIN=/tmp/pgtest/node_modules/@embedded-postgres/linux-x64/native/bin
DATA=/tmp/kindora-pgdata
export PATH="$PGBIN:$PATH"

pkill -9 postgres 2>/dev/null; sleep 1
rm -rf "$DATA" /tmp/kindora-pgsock && mkdir -p /tmp/kindora-pgsock
"$PGBIN/initdb" -D "$DATA" -U kindora --auth=trust -E UTF8 > /dev/null 2>&1 || exit 1
"$PGBIN/pg_ctl" -D "$DATA" -l /tmp/kindora-pg2.log -o "-p 5433 -k /tmp/kindora-pgsock -c fsync=off" start -w > /dev/null 2>&1 || exit 1
sleep 1

psql_client() { node /home/z/my-project/scripts/create-shadow-db.js; }
psql_client

cd /home/z/my-project/kindora/backend
npx prisma migrate diff \
  --from-migrations prisma/migrations \
  --to-schema-datamodel prisma/schema.prisma \
  --shadow-database-url "postgresql://kindora@localhost:5433/kindora_shadow" \
  --exit-code > /tmp/prisma-diff.txt 2>&1
DIFF_EXIT=$?
echo "prisma migrate diff exit code: $DIFF_EXIT (0 = no difference)"
cat /tmp/prisma-diff.txt | head -30

"$PGBIN/pg_ctl" -D "$DATA" stop -m fast > /dev/null 2>&1
[ "$DIFF_EXIT" = "0" ] && echo "STRUCTURAL_CHECK=PASS migrations match schema exactly" || echo "STRUCTURAL_CHECK=FAIL differences detected (see /tmp/prisma-diff.txt)"
exit $DIFF_EXIT
